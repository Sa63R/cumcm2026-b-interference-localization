"""Bounded continuous-angle enclosures for an executable one-read clear plan.

The input polygon is the parent's conservative binary64 outer region. Angular
bin containment is a set-theoretic guarantee in exact geometry; the numerical
implementation inherits that geometry contract, adds padding, and requires a
new live vertex certificate before clearing. This is not interval arithmetic,
a posterior, an expected-cost optimizer, or a certificate of global optimality.
"""

from dataclasses import dataclass
import math
import time

from geometry import HalfPlane, bearing_halfplanes, clip_polygon, minimum_enclosing_circle
from planning.probe_candidates import geometry_candidates
from simulator_client.state import Position


BIN_WIDTH_DEG = .5
BIN_COUNT = 720
ANGLE_ERROR_DEG = 1.005
GEOMETRY_MARGIN_M = 1e-6
RECEPTION_LIMIT_M = 1000. - 1e-5
CLEAR_LIMIT_M = 19.9


class EnvelopeBudgetExceeded(Exception):
    pass


class EnvelopeBudget:
    def __init__(self, maximum_bins=12000, maximum_seconds=2., *, clock=time.perf_counter):
        if type(maximum_bins) is not int or maximum_bins < 0:
            raise ValueError("maximum_bins must be a nonnegative integer")
        if not math.isfinite(maximum_seconds) or maximum_seconds < 0:
            raise ValueError("maximum_seconds must be finite and nonnegative")
        self.maximum_bins, self.maximum_seconds, self.clock = maximum_bins, maximum_seconds, clock
        self.started, self.used = clock(), 0

    def check(self):
        if self.clock() - self.started >= self.maximum_seconds:
            raise EnvelopeBudgetExceeded("wall_budget")

    def take(self):
        self.check()
        if self.used >= self.maximum_bins:
            raise EnvelopeBudgetExceeded("geometry_budget")
        self.used += 1


def movement_us(a, b):
    return round(Position.coerce(a).distance_to(Position.coerce(b)) / 5 * 1e6)


def bin_index(bearing):
    if isinstance(bearing, bool) or not isinstance(bearing, (int, float)) or not math.isfinite(bearing):
        raise ValueError("bearing must be finite")
    return int((bearing % 360.) // BIN_WIDTH_DEG)


def original_candidates(region, current, first_bearing, old_best):
    """Exactly the original 9 plus axis_quantile's 14, without current added."""
    center = Position(*region.enclosing_disk().center)
    theta = math.radians(first_bearing)
    transverse = (-math.sin(theta), math.cos(theta))
    points = [center]
    for fraction in (.5, 1.):
        anchor = Position(current.x + fraction * (center.x - current.x),
                          current.y + fraction * (center.y - current.y))
        for offset in (-150., -50., 50., 150.):
            points.append(Position(anchor.x + offset * transverse[0],
                                   anchor.y + offset * transverse[1]))
    extra, _ = geometry_candidates(region, mode="axis_quantile", old_best=old_best)
    # Exact duplicates do not create extra actions. Generation order is stable.
    return tuple(dict.fromkeys(points + extra))


def feedback_polygon(vertices, point, index):
    if type(index) is not int or not 0 <= index < BIN_COUNT:
        raise ValueError("invalid angular bin")
    result = tuple(vertices)
    for hp in bearing_halfplanes((point.x, point.y), (index + .5) * BIN_WIDTH_DEG,
                                 ANGLE_ERROR_DEG + BIN_WIDTH_DEG / 2):
        # Dropping future positive-radius/negative-comparison cuts only makes
        # this enclosure larger. No imagined response enters the live region.
        result = clip_polygon(result, HalfPlane(hp.a, hp.b, hp.c + GEOMETRY_MARGIN_M))
    return result


def vertex_radius(point, vertices):
    return max((Position.coerce(point).distance_to(Position(*v)) for v in vertices), default=math.inf)


@dataclass(frozen=True)
class EnvelopePlan:
    point: Position
    branches: tuple
    upper_us: int
    first_movement_us: int
    switch_s: int
    maximum_radius_m: float

    def branch(self, bearing):
        return self.branches[bin_index(bearing)]

    def evidence(self):
        return {"point": [self.point.x, self.point.y], "upper_time_us": self.upper_us,
                "first_movement_us": self.first_movement_us, "switch_s": self.switch_s,
                "maximum_feedback_radius_m": self.maximum_radius_m,
                "bin_width_deg": BIN_WIDTH_DEG, "bin_count": BIN_COUNT,
                "near_tail_us": 5_000_000, "no_signal_branch": "excluded_by_full_region_reception",
                "branches": [dict(index=i, **branch) for i, branch in enumerate(self.branches)
                             if branch is not None]}


def certify_plan(vertices, current, point, switch_s, budget, *, cutoff_us=math.inf):
    """Return a whole-circle completion plan, or an explicit rejection.

    Empty bins are certified impossible under the outer polygon. near always
    has its own 5s tail. A nonempty too-wide bin rejects this sufficient test;
    it does not prove the exact finer-feedback problem has no such plan.
    Partial maximum costs safely prune only this declared worst-case score.
    """
    vertices, current, point = tuple(vertices), Position.coerce(current), Position.coerce(point)
    if switch_s not in (0, 1):
        raise ValueError("switch_s must be zero or one")
    if not vertices or any(not math.isfinite(v) for p in vertices for v in p):
        return None, "invalid_region"
    if vertex_radius(point, vertices) > RECEPTION_LIMIT_M:
        return None, "reception_not_certified"
    first_move = movement_us(current, point)
    fixed = first_move + (5 + switch_s) * 1_000_000
    worst_tail = 5_000_000  # A real near result clears at the measured point.
    if fixed + worst_tail >= cutoff_us:
        return None, "complete_cost_lower_bound"
    branches, maximum = [], 0.
    for index in range(BIN_COUNT):
        budget.take()
        polygon = feedback_polygon(vertices, point, index)
        if not polygon:
            branches.append(None)
            continue
        circle = minimum_enclosing_circle(polygon)
        center = Position(*circle.center)
        radius = vertex_radius(center, polygon)  # Do not trust a cached radius alone.
        if not math.isfinite(radius) or radius > CLEAR_LIMIT_M - GEOMETRY_MARGIN_M:
            return None, "feedback_bin_not_clearable"
        safe = max(0., CLEAR_LIMIT_M - GEOMETRY_MARGIN_M - radius)
        distance = point.distance_to(center)
        fraction = min(1., safe / distance) if distance else 0.
        clear = Position(center.x + fraction * (point.x - center.x),
                         center.y + fraction * (point.y - center.y))
        clear_radius = vertex_radius(clear, polygon)
        if not math.isfinite(clear_radius) or clear_radius > CLEAR_LIMIT_M:
            return None, "numeric_clear_certificate_failed"
        tail = movement_us(point, clear) + 5_000_000
        worst_tail, maximum = max(worst_tail, tail), max(maximum, radius)
        if fixed + worst_tail >= cutoff_us:
            return None, "complete_cost_lower_bound"
        branches.append({"clear_point": [clear.x, clear.y],
                         "enclosing_center": [center.x, center.y],
                         "enclosing_radius_m": radius, "clear_radius_upper_m": clear_radius,
                         "tail_time_us": tail})
    budget.check()
    if not any(branch is not None for branch in branches):
        return None, "no_nonempty_direction_bin"
    return EnvelopePlan(point, tuple(branches), fixed + worst_tail, first_move, switch_s, maximum), "certified"


def choose_plan(region, current, first_bearing, observed, old_best, parent_point,
                parent_nominal_complete_s, switch_s, budget):
    """Same 23-point family; conservative but heuristic cross-model screen."""
    proposed = original_candidates(region, current, first_bearing, old_best)
    if parent_point not in proposed:
        return None, {"reason": "parent_not_in_original_family", "candidates": []}
    legal = [p for p in proposed if (round(p.x, 6), round(p.y, 6)) not in observed
             and vertex_radius(p, region.vertices) <= RECEPTION_LIMIT_M]
    limit = parent_nominal_complete_s * 1e6
    if not math.isfinite(limit):
        return None, {"reason": "nonfinite_parent_proxy", "candidates": []}
    selected, parent_upper, records = None, None, []
    # Evaluate parent's envelope without the proxy cutoff to report the same
    # complete-UB scale when it can be certified; others can be cost-pruned.
    for p in sorted(legal, key=lambda p: (p != parent_point, current.distance_to(p), p.x, p.y)):
        plan, reason = certify_plan(region.vertices, current, p, switch_s, budget,
                                    cutoff_us=math.inf if p == parent_point else limit)
        records.append({"position": [p.x, p.y], "parent": p == parent_point,
                        "reason": reason, "upper_time_us": plan.upper_us if plan else None})
        if p == parent_point and plan:
            parent_upper = plan.upper_us
        if plan and plan.upper_us < limit - 1e-3:  # 1 ns comparison guard, not an effect threshold.
            selected, limit = plan, plan.upper_us
    budget.check()
    return selected, {"reason": "selected" if selected else "no_certified_plan_beats_parent_proxy",
                      "proposed_candidates": len(proposed), "legal_candidates": len(legal),
                      "parent_complete_upper_us": parent_upper, "candidates": records,
                      "screening": "worst_case_plan_UB_vs_parent_nominal_proxy_heuristic_not_dominance"}
