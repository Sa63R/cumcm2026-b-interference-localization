"""Isolated continuous-feedback completion experiment over derived silence.

`enabled=False` delegates to the fully enabled derived-silence parent. Candidate
actions may change only after whole-circle certification and a complete-cost
screen. Actual feedback is followed by the certified clear point as priced;
unexpected feedback/geometry explicitly invalidates the bound and falls back.
"""

from copy import deepcopy
import math
import time

from planning.feedback_envelope import (CLEAR_LIMIT_M, EnvelopeBudget, EnvelopeBudgetExceeded,
                                        choose_plan, vertex_radius)
from simulator_client.state import Position
from .derived_silence_state_search import DerivedSilenceStateSearch


LIMITS = {"bins_per_call": 12000, "bins_per_case": 60000, "seconds_per_call": 2.,
          "seconds_per_case": 20., "calls_per_case": 32}


class FeedbackEnvelopeStateSearch(DerivedSilenceStateSearch):
    def __init__(self, client, max_actions, max_active_probes, config, *, enabled=True,
                 relative_silence=True, stop_scan_at_16=True):
        if type(enabled) is not bool:
            raise ValueError("enabled must be boolean")
        super().__init__(client, max_actions, max_active_probes, config, enabled=True,
                         relative_silence=relative_silence, stop_scan_at_16=stop_scan_at_16)
        self.envelope_enabled = enabled
        self.envelope_log = []
        self.envelope_bins = self.envelope_calls = 0
        self.envelope_seconds = 0.
        self._envelope_pending = None
        self.report.strategy_parameters.update({
            "feedback_envelope_enabled": enabled, "feedback_envelope_log": self.envelope_log,
            "feedback_envelope_limits": dict(LIMITS),
            "feedback_envelope_scope": "continuous-angle sufficient enclosures under parent binary64 outer-region contract; padded, not formal interval arithmetic; live clear vertices rechecked",
            "feedback_envelope_comparison": "complete worst-case plan UB versus parent nominal score plus common service; heuristic, not expectation or dominance",
        })

    def _invalidate(self, reason):
        if self._envelope_pending is not None:
            self._envelope_pending["log"].update(execution_status="bound_invalidated", invalidation_reason=reason)
            self._envelope_pending = None

    def _next_probe(self, channel, index):
        if not self.envelope_enabled:
            return super()._next_probe(channel, index)
        self._invalidate("parent_requested_another_probe")
        before = len(self.probe_log)
        parent = super()._next_probe(channel, index)
        if parent is None:
            return None
        log = {"channel": channel, "index": index,
               "after_actual_action_count": len(self.report.action_history),
               "current_position": [self.client.state.position.x, self.client.state.position.y],
               "current_channel": self.client.state.current_channel,
               "virtual_time_s": self.client.state.virtual_time_s,
               "parent_position": [parent.x, parent.y], "selected": False,
               "comparison_started": False, "comparison_complete": False}
        self.envelope_log.append(log)
        region = self.regions.get(channel)
        if (channel not in self.detected - self.cleared or channel in self.near_points
                or not region or not region.vertices or self.state_config.probe_model != "radius_proxy"
                or not self.state_config.active_probe_search or len(self.probe_log) != before + 1
                or self.probe_log[-1].get("family") != "axis_quantile"):
            log["reason"] = "parent_family_or_live_state_not_eligible"
            return parent
        baseline_log = deepcopy(self.probe_log[-1])
        log["baseline_probe_log"] = baseline_log
        parent_score = baseline_log.get("score_s")
        if not isinstance(parent_score, (int, float)) or not math.isfinite(parent_score):
            log["reason"] = "nonfinite_parent_proxy"
            return parent
        switch = int(self.client.state.current_channel != channel)
        proxy = parent_score + 5 + switch + 5
        log["parent_nominal_complete_s"] = proxy
        if self.envelope_calls >= LIMITS["calls_per_case"]:
            log["reason"] = "case_call_budget"
            return parent
        remaining_seconds = max(0., LIMITS["seconds_per_case"] - self.envelope_seconds)
        remaining_real = getattr(self.client, "remaining_real_time_s", None)
        if remaining_real is not None:
            # Keep the parent's two-second protocol/finalization reserve.
            remaining_seconds = min(remaining_seconds, max(0., remaining_real - 2.))
        budget = EnvelopeBudget(min(LIMITS["bins_per_call"], LIMITS["bins_per_case"] - self.envelope_bins),
                                min(LIMITS["seconds_per_call"], remaining_seconds))
        self.envelope_calls += 1
        log["comparison_started"] = True
        began = time.perf_counter()
        try:
            plan, details = choose_plan(region, self.client.state.position, self.first_bearings[channel],
                self.observed_positions.get(channel, set()), Position(*baseline_log["old_best_position"]),
                parent, proxy, switch, budget)
            log.update(details)
            log["comparison_complete"] = True
        except EnvelopeBudgetExceeded as error:
            log.update(reason=str(error), comparison_incomplete=True)
            return parent  # No partial-budget winner may cause an action.
        finally:
            elapsed = time.perf_counter() - began
            self.envelope_bins += budget.used
            self.envelope_seconds += elapsed
            log.update(geometry_bin_evaluations=budget.used, envelope_runtime_s=elapsed,
                       case_geometry_bins=self.envelope_bins, case_envelope_runtime_s=self.envelope_seconds)
        if plan is None:
            return parent
        maximum = self.client.state.max_virtual_duration_s
        maximum = min(360000., maximum) if maximum is not None else 360000.
        if (self.actions + 2 > self.max_actions - 1
                or self.client.state.virtual_time_s + plan.upper_us / 1e6 > maximum - 1e-6):
            log["reason"] = "complete_plan_exceeds_action_or_virtual_budget"
            return parent
        log.update(selected=True, changed_probe=plan.point != parent, plan=plan.evidence(),
                   execution_status="awaiting_real_measure", expected_measure_ordinal=len(self.report.action_history)+1)
        self._envelope_pending = {"channel": channel, "plan": plan, "log": log,
                                  "start_time_s": self.client.state.virtual_time_s, "measured": False}
        # Preserve parent's complete log as an explicit comparator; the main
        # probe log must name the actual action and its different scoring scale.
        self.probe_log[-1].clear()
        self.probe_log[-1].update(channel=channel, index=index,
            position=[plan.point.x, plan.point.y], score_s=plan.upper_us/1e6,
            score_kind="continuous_feedback_completion_UB_heuristic_screen",
            family="axis_quantile", parent_probe_log=baseline_log,
            total_runtime_s=baseline_log["total_runtime_s"]+log["envelope_runtime_s"],
            envelope_runtime_s=log["envelope_runtime_s"])
        return plan.point

    def _perform(self, action, position, channel, phase):
        pending = self._envelope_pending
        expected_measure = bool(pending and not pending["measured"] and action == "measure"
            and phase == "active_localization" and channel == pending["channel"]
            and Position.coerce(position) == pending["plan"].point
            and len(self.report.action_history)+1 == pending["log"]["expected_measure_ordinal"])
        if pending and not pending["measured"] and not expected_measure:
            self._invalidate("different_action_before_planned_measure")
        try:
            response = super()._perform(action, position, channel, phase)
        except Exception:
            if expected_measure:
                self._invalidate("planned_measure_did_not_return_successfully")
            raise
        if not expected_measure:
            return response
        plan, log = pending["plan"], pending["log"]
        log.update(actual_measure_ordinal=len(self.report.action_history),
                   actual_measure_result=response["measure_result"],
                   actual_measure_time_s=self.client.state.virtual_time_s)
        kind = response["measure_result"]
        if kind == "near":
            clear, tail = plan.point, 5_000_000
        elif kind == "direction":
            branch = plan.branch(response["svd_deg"])
            if branch is None:
                self._invalidate("actual_direction_in_predicted_empty_bin")
                return response
            clear, tail = Position(*branch["clear_point"]), branch["tail_time_us"]
            region = self.regions.get(channel)
            actual_radius = vertex_radius(clear, region.vertices if region else ())
            log["actual_clear_vertex_radius_m"] = actual_radius if math.isfinite(actual_radius) else None
            if not math.isfinite(actual_radius) or actual_radius > CLEAR_LIMIT_M:
                self._invalidate("actual_region_does_not_certify_priced_clear")
                return response
        else:
            self._invalidate("guaranteed_reception_contradicted_by_no_signal")
            return response
        pending.update(measured=True, clear_point=clear, tail_us=tail, kind=kind)
        log.update(execution_status="awaiting_priced_clear", priced_clear_point=[clear.x, clear.y],
                   actual_branch_tail_us=tail, expected_clear_ordinal=len(self.report.action_history)+1)
        return response

    def _clear(self, position, channel, phase):
        pending = self._envelope_pending
        if not pending or not pending["measured"] or channel != pending["channel"]:
            return super()._clear(position, channel, phase)
        plan, log, clear = pending["plan"], pending["log"], pending["clear_point"]
        valid = (self.client.state.position == plan.point
                 and self.client.state.current_channel == channel
                 and len(self.report.action_history)+1 == log["expected_clear_ordinal"])
        if pending["kind"] == "near":
            valid = valid and self.near_points.get(channel) == plan.point
        else:
            region = self.regions.get(channel)
            valid = valid and vertex_radius(clear, region.vertices if region else ()) <= CLEAR_LIMIT_M
        if not valid:
            self._invalidate("priced_tail_state_changed_before_clear")
            return super()._clear(position, channel, phase)
        # Avoid EfficientSearch's old MEC subdisk projection: this exact point
        # was priced, and has just been certified using the real feedback.
        new_phase = "feedback_envelope_near_clear" if pending["kind"] == "near" else "feedback_envelope_certified_clear"
        self._envelope_pending = None
        try:
            return super()._clear(clear, channel, new_phase)
        finally:
            last = self.report.action_history[-1] if self.report.action_history else None
            accepted = bool(last and last["action"] == "clear" and last["channel"] == channel
                            and last["position"] == [clear.x, clear.y]
                            and len(self.report.action_history) == log["expected_clear_ordinal"])
            elapsed = self.client.state.virtual_time_s - pending["start_time_s"]
            log.update(execution_status="completed" if accepted and last["result"] == "success" else "clear_not_successful",
                       actual_clear_ordinal=len(self.report.action_history) if accepted else None,
                       actual_complete_time_s=elapsed,
                       completion_bound_honored=bool(accepted and last["result"] == "success"
                                                    and elapsed <= plan.upper_us/1e6 + 2e-6))


def run_feedback_envelope_state_search(client, *, problem=3, max_actions=10000,
                                      max_active_probes=6, config=None, enabled=True,
                                      relative_silence=True, stop_scan_at_16=True):
    if problem != 3:
        raise ValueError("Feedback envelope supports Q3 only")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("max_active_probes must be in [0,30]")
    return FeedbackEnvelopeStateSearch(client, max_actions, max_active_probes, config,
        enabled=enabled, relative_silence=relative_silence, stop_scan_at_16=stop_scan_at_16).run()
