"""Reorder the parent's legal fixed tasks using directional probe costs.

This is an isolated heuristic over derived-silence base 760af823. Parent
relocation runs first and remains authoritative for cover geometry. Only
the subsequent frozen task-order objective changes; execution remains the
parent's observation-only resolver, scanner, clear certificates and exit.
"""

from copy import deepcopy
from dataclasses import asdict
import math
import time

from planning.directed_state_route import solve_directed_state_route
from planning.localization_transition import (
    LocalizationTarget, LocalizationTransitions, TransitionUnavailable,
)
from planning.state_route import RouteTask
from simulator_client.state import Position

from .derived_silence_state_search import DerivedSilenceStateSearch


def _task_record(task):
    return {"kind": task[0], "channel": task[1],
            "exit_representative": [task[2].x, task[2].y]}


def _price_order(order, tasks, matrix, initial, scan_source_s):
    """Price a complete validated route in the current frozen objective."""
    result, last = 0.0, None
    remaining_sources = sum(task.is_source for task in tasks)
    for j in order:
        result += (initial[j] if last is None else matrix[last][j]) + tasks[j].service_s
        if tasks[j].is_source:
            remaining_sources -= 1
        else:
            result += scan_source_s * remaining_sources
        last = j
    return result


class DirectedLocalizationStateSearch(DerivedSilenceStateSearch):
    def __init__(self, client, max_actions, max_active_probes, config, *,
                 enabled=True, transition_max_runtime_s=8.0,
                 relative_silence=True, stop_scan_at_16=True, incumbent_enabled=True):
        if type(enabled) is not bool:
            raise ValueError("enabled must be boolean")
        if type(incumbent_enabled) is not bool:
            raise ValueError("incumbent_enabled must be boolean")
        if (isinstance(transition_max_runtime_s, bool)
                or not isinstance(transition_max_runtime_s, (int, float))
                or not math.isfinite(transition_max_runtime_s)
                or not 0 < transition_max_runtime_s <= 60):
            raise ValueError("transition_max_runtime_s must be in (0,60]")
        # Disabling ONLY this candidate preserves the combined 760 parent.
        super().__init__(client, max_actions, max_active_probes, config,
                         enabled=True, relative_silence=relative_silence,
                         stop_scan_at_16=stop_scan_at_16)
        self.directed_enabled = enabled
        self.incumbent_enabled = incumbent_enabled
        self.transition_max_runtime_s = transition_max_runtime_s
        self.directed_log = []
        self._pending_directed = None
        self.report.strategy_parameters.update({
            "directed_localization_config": {"enabled": enabled,
                "transition_max_runtime_s": transition_max_runtime_s,
                "incumbent_enabled": incumbent_enabled},
            "directed_localization_log": self.directed_log,
            "directed_localization_scope": "fixed exits and public-prefix nominal probe costs; no physical-time bound or global Q3 optimality",
        })

    def _next_task(self, remaining):
        if not self.directed_enabled:
            return super()._next_task(remaining)
        if self._pending_directed is not None:
            self._pending_directed["execution_status"] = "no_physical_action_before_next_decision"
            self._pending_directed = None
        began = time.perf_counter()
        expansions_before = self.total_expansions
        parent = super()._next_task(remaining)
        if parent is None:
            return None
        parent_expansions = self.total_expansions
        parent_log = deepcopy(self.search_log[-1])
        log = {"after_actual_action_count": len(self.report.action_history),
               "virtual_time_s": self.client.state.virtual_time_s,
               "current_channel": self.client.state.current_channel,
               "current_position": [self.client.state.position.x, self.client.state.position.y],
               "parent_selected": _task_record(parent), "parent_planning": parent_log,
               "expansions_before_parent": expansions_before,
               "expansions_after_parent": parent_expansions,
               "selected": _task_record(parent), "status": "parent_fallback",
               "remaining_after_parent": [[p.x, p.y] for p in remaining]}
        self.directed_log.append(log)
        builder = None
        try:
            config = self.state_config
            if not config.active_probe_search or config.probe_model != "radius_proxy" or self.max_active_probes == 0:
                raise TransitionUnavailable("parent_probe_model_not_applicable")
            if self.actions >= self.max_actions - 1:
                raise TransitionUnavailable("action_budget")
            budget = max(0, min(config.max_expansions,
                               config.max_total_expansions - self.total_expansions))
            if budget == 0:
                raise TransitionUnavailable("route_expansion_budget")
            # Parent already committed any legal relocation. Preserve its
            # list order and use identical sorted, unblocked known sources.
            sources = [("source", c, point) for c in sorted(self.detected-self.cleared-self.blocked)
                       if (point := self._target(c)) is not None]
            covers = [("cover", None, p) for p in remaining]
            if config.stop_discovery_at_16 and len(self.detected | self.cleared) == 16:
                covers = []
            tasks = covers + sources
            targets = {}
            for j, (kind, channel, _) in enumerate(tasks):
                if kind != "source" or channel in self.near_points:
                    continue
                region = self.regions.get(channel)
                if region is None or not region.vertices:
                    raise TransitionUnavailable("missing_public_region")
                if region.enclosing_disk().radius <= 19.9:
                    continue
                if channel not in self.first_bearings:
                    raise TransitionUnavailable("missing_first_bearing")
                targets[j] = LocalizationTarget(
                    channel, region.copy(), self.first_bearings[channel],
                    frozenset(self.observed_positions.get(channel, set())))
            if not targets:
                raise TransitionUnavailable("no_uncertain_source")
            background = max(0, 20-len(self.cleared)-len(sources))
            finite = [RouteTask(p, kind == "source", 5.0 if kind == "source" else 6.0*background)
                      for kind, _, p in tasks]
            model_started = time.perf_counter()

            def check_budget():
                if time.perf_counter() - model_started >= self.transition_max_runtime_s:
                    raise TransitionUnavailable("transition_wall_budget")
                real_left = getattr(self.client, "remaining_real_time_s", None)
                if real_left is not None and real_left <= 2.0:
                    raise TransitionUnavailable("real_deadline_reserve")

            check_budget()
            builder = LocalizationTransitions(finite, targets,
                weight=config.probe_uncertainty_weight, check_budget=check_budget)
            matrix, initial = builder.build(self.client.state.position)
            incumbent_order = None
            if self.incumbent_enabled:
                supplied = self._frozen_parent_route
                if (not supplied or supplied["tasks"] != tuple(tasks)
                        or supplied["start"] != self.client.state.position
                        or supplied["after_actual_action_count"] != len(self.report.action_history)):
                    raise TransitionUnavailable("parent_route_correspondence_mismatch")
                incumbent_order = supplied["order"]
                if (len(incumbent_order) != len(tasks)
                        or any(type(i) is not int for i in incumbent_order)
                        or set(incumbent_order) != set(range(len(tasks)))
                        or tasks[incumbent_order[0]] != parent):
                    raise TransitionUnavailable("invalid_parent_complete_route")
                parent_new_cost = _price_order(incumbent_order, finite, matrix, initial,
                                               config.scan_source_s)
                log.update(incumbent_supplied=True, incumbent_order=list(incumbent_order),
                           parent_order_cost_new_model_s=parent_new_cost)
            else:
                log["incumbent_supplied"] = False
            result = solve_directed_state_route(finite, self.client.state.position,
                scan_source_s=config.scan_source_s, max_expansions=budget,
                travel_times_s=matrix, initial_times_s=initial,
                incumbent_order=incumbent_order)
            self.total_expansions += result.expanded
            if incumbent_order is not None:
                log.update(candidate_minus_parent_order_same_model_s=result.cost_s-parent_new_cost,
                           incumbent_result_order=list(result.order), incumbent_result_cost_s=result.cost_s,
                           returned_order_is_parent=tuple(result.order) == tuple(incumbent_order))
                if result.cost_s > parent_new_cost + 1e-9:
                    raise TransitionUnavailable("supplied_incumbent_bound_violated")
            selected = tasks[result.order[0]]
            log.update(status="directed_selected", selected=_task_record(selected),
                changed_first_task=selected != parent,
                tasks=[{**_task_record(task), "service_s": ft.service_s}
                       for task, ft in zip(tasks, finite)],
                uncertain_target_indices=sorted(targets), travel_times_s=matrix,
                initial_times_s=initial, scan_source_s=config.scan_source_s,
                route_budget=budget, route=asdict(result),
                execution_status="awaiting_first_physical_action")
            # Preserve the entire parent's proposal in the dedicated log,
            # while the main planning row identifies the task actually used.
            self.search_log[-1] = {
                **parent_log, "selected_kind": selected[0], "selected_channel": selected[1],
                "selected_point": [selected[2].x, selected[2].y],
                **{k: v for k, v in asdict(result).items() if k != "order"},
                "expanded": self.total_expansions-expansions_before,
                "model_gap_s": max(0.0, result.cost_s-result.lower_bound_s),
                "bound_scope": "Frozen directed localization proxy only; excludes future feedback and exact switching; not Q3",
                "directed_log_index": len(self.directed_log)-1,
            }
            self._pending_directed = log
            return selected
        except (TransitionUnavailable, ValueError, ArithmeticError) as error:
            # Reject the whole incomplete model: never mix partial new rows
            # with old rows or install hypothetical measurements into policy.
            log["fallback_reason"] = str(error)
            return parent
        finally:
            if builder is not None:
                log["transition_audit"] = builder.audit
            log["expansions_after_decision"] = self.total_expansions
            log["parent_expansions"] = parent_expansions-expansions_before
            log["directed_expansions"] = self.total_expansions-parent_expansions
            log["total_runtime_s"] = time.perf_counter()-began
            self.search_log[-1]["runtime_s"] = log["total_runtime_s"]

    def _perform(self, action, position, channel, phase):
        pending = self._pending_directed
        before = len(self.report.action_history)
        try:
            return super()._perform(action, position, channel, phase)
        finally:
            if pending is not None:
                if len(self.report.action_history) > before:
                    actual = self.report.action_history[before]
                    task = pending["selected"]
                    matches = (actual["channel"] == task["channel"] if task["kind"] == "source"
                               else actual["phase"] == "coverage" and actual["position"] == task["exit_representative"])
                    pending.update(execution_status="first_physical_action_recorded",
                        first_actual_action_ordinal=before+1,
                        first_actual_action=deepcopy(actual), selected_task_matches_actual=matches)
                else:
                    pending["execution_status"] = "interrupted_before_physical_action"
                self._pending_directed = None

    def run(self):
        try:
            return super().run()
        finally:
            if self._pending_directed is not None:
                self._pending_directed["execution_status"] = "ended_without_physical_action"
                self._pending_directed = None


def run_directed_localization_state_search(client, *, problem=3, max_actions=10000,
        max_active_probes=6, config=None, enabled=True, transition_max_runtime_s=8.0,
        relative_silence=True, stop_scan_at_16=True, incumbent_enabled=True):
    if problem != 3:
        raise ValueError("Directed localization supports Q3 only")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("max_active_probes must be in [0,30]")
    return DirectedLocalizationStateSearch(client, max_actions, max_active_probes, config,
        enabled=enabled, transition_max_runtime_s=transition_max_runtime_s,
        relative_silence=relative_silence, stop_scan_at_16=stop_scan_at_16,
        incumbent_enabled=incumbent_enabled).run()
