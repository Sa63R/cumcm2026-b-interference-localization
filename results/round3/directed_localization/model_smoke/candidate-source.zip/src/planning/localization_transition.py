"""Observation-only directional costs for one frozen task-order decision.

An uncertain source's incoming edge replaces centre-to-centre movement with
the unchanged refined radius score plus the first 5 s measurement. That
score already contains entry movement and nominal post-probe travel. Clear
service (5 s) belongs to the task, exactly once, not to these edges.
Future switches, discoveries and exact terminal positions are NOT modelled.
"""

from dataclasses import dataclass
import math
import time

from planning.probe_candidates import geometry_candidates
from planning.radius_probe import choose_radius_probe
from simulator_client.state import Position


class TransitionUnavailable(Exception):
    """The complete finite matrix could not be safely constructed."""


@dataclass(frozen=True)
class LocalizationTarget:
    # region and observed must be independent public-prefix snapshots.
    channel: int
    region: object
    first_bearing: float
    observed: frozenset


class LocalizationTransitions:
    """Build a matrix without access to a client, simulator or hidden world.

    `tasks` have frozen exit representatives. Only uncertain source targets
    appear in `targets`; covers and already certified/near sources retain
    the parent's direct representative travel. No prediction mutates policy
    state or enters its actual observation log.
    """

    def __init__(self, tasks, targets, *, weight=0.5, check_budget=None):
        self.tasks = tuple(tasks)
        # Take our own cheap copies, including the lazy MEC cache. Even a
        # caller passing a live region must not see planning cache updates.
        self.targets = {j: LocalizationTarget(t.channel, t.region.copy(),
                        t.first_bearing, frozenset(t.observed)) for j, t in targets.items()}
        self.weight = weight
        self.check_budget = check_budget or (lambda: None)
        self.cache = {}
        self.audit = {"score_calls": 0, "geometry_updates": 0,
                      "score_runtime_s": 0.0, "runtime_s": 0.0,
                      "cache_hits": 0, "arcs": [], "complete": False}

    def _score(self, target, origin, *, extra_points=()):
        self.check_budget()
        self.audit["score_calls"] += 1
        point, log = choose_radius_probe(
            target.region, origin, target.first_bearing, target.observed,
            self.weight, extra_points=extra_points)
        # Account for every completed scoring pass, including a pass whose
        # result makes the whole matrix unavailable. Never sum total runtime
        # again with the component runtime; they measure overlapping work.
        self.audit["geometry_updates"] += log["geometry_updates"]
        self.audit["score_runtime_s"] += log["runtime_s"]
        if point is None or not math.isfinite(log["score_s"]) or log["score_s"] < 0:
            raise TransitionUnavailable("no_finite_guaranteed_fresh_probe")
        return point, log

    def _edge(self, origin, index):
        origin = Position.coerce(origin)
        target = self.targets.get(index)
        if target is None:
            return origin.distance_to(self.tasks[index].position) / 5.0
        key = (index, origin.x, origin.y)
        if key in self.cache:
            self.audit["cache_hits"] += 1
            return self.cache[key]
        self.check_budget()
        old, before = self._score(target, origin)
        extra, geometry = geometry_candidates(target.region, mode="axis_quantile", old_best=old)
        point, after = self._score(target, origin, extra_points=extra)
        # The nested set cannot be worse under the SAME unchanged score.
        # A violated numeric/model contract rejects the complete new matrix.
        if after["score_s"] > before["score_s"] + 1e-9:
            raise TransitionUnavailable("nested_probe_score_inconsistent")
        cost = after["score_s"] + 5.0
        if not math.isfinite(cost):
            raise TransitionUnavailable("nonfinite_edge")
        self.audit["arcs"].append({
            "target_index": index, "channel": target.channel,
            "origin": [origin.x, origin.y], "first_probe": [point.x, point.y],
            "score_s": after["score_s"], "first_measurement_s": 5.0,
            "incoming_cost_s": cost, "source_clear_service_in_edge_s": 0.0,
            "old9_score_s": before["score_s"], "old9_candidates": before["candidates"],
            "refined_candidates": after["candidates"], **geometry,
        })
        self.cache[key] = cost
        return cost

    def build(self, start):
        began = time.perf_counter()
        try:
            initial = [self._edge(start, j) for j in range(len(self.tasks))]
            matrix = [[0.0 if i == j else self._edge(task.position, j)
                       for j in range(len(self.tasks))]
                      for i, task in enumerate(self.tasks)]
            self.check_budget()
            self.audit["complete"] = True
            return matrix, initial
        finally:
            self.audit["runtime_s"] = time.perf_counter() - began


__all__ = ["LocalizationTarget", "LocalizationTransitions", "TransitionUnavailable"]
