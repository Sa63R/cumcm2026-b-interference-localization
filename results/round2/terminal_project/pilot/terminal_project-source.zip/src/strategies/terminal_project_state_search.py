"""Two-dimensional final station projection; disabled means the ray ablation."""
from dataclasses import asdict

from planning.terminal_projection import project_terminal_cover
from .terminal_cover_state_search import TerminalCoverSearch


class TerminalProjectSearch(TerminalCoverSearch):
    def __init__(self, client, max_actions, max_active_probes, config, enabled):
        super().__init__(client, max_actions, max_active_probes, config, True)
        self.project_enabled = enabled
        self.projection_log = []
        self.report.strategy_parameters.update(
            terminal_project_enabled=enabled, terminal_projection_log=self.projection_log,
            terminal_cover_scope="One final cover, no observed uncleared source, public count below 16; ray incumbent then 2D witness-disk projection; unknown channels still scanned")

    def _choose_replacement(self, old, current):
        ray = super()._choose_replacement(old, current)
        if not self.project_enabled:
            return ray
        try:
            result = project_terminal_cover(tuple(self.discovery_stations), current, ray.point)
        except ValueError as error:
            self.projection_log.append({"after_actual_action_count": len(self.report.action_history),
                                        "status": "projection_fallback_to_ray", "reason": str(error),
                                        "ray_position": [ray.point.x, ray.point.y]})
            return ray
        self.projection_log.append({"after_actual_action_count": len(self.report.action_history),
                                    "ray_position": [ray.point.x, ray.point.y],
                                    "ray_incoming_m": current.distance_to(ray.point), **asdict(result)})
        return result


def run_terminal_project_state_search(client, *, problem=3, max_actions=10000,
                                      max_active_probes=6, config=None, enabled=True):
    if problem != 3:
        raise ValueError("Terminal projection is Q3 only")
    if type(enabled) is not bool:
        raise ValueError("enabled must be boolean")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("max_active_probes must be integer in [0,30]")
    return TerminalProjectSearch(client, max_actions, max_active_probes, config, enabled).run()
