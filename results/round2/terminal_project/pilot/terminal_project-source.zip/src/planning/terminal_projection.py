"""Exchange method for a final coverage station, with feasible ray fallback.

Whole-disk coverage uses finite Voronoi witnesses with the same geometry as
the independent existing oracle. Necessary witness disks give a relaxation,
not a replacement for the final full-domain coverage check.
"""
from dataclasses import dataclass
from fractions import Fraction
import math

from simulator_client.state import Position


@dataclass(frozen=True)
class CoverWitness:
    radius_m: float
    point: Position


def cover_witness(stations, arena_radius=1800.):
    """Return the full Voronoi maximum and an attaining float witness.

    Boundary roundoff can put a generated witness just outside the arena;
    callers MUST validate it before treating it as a necessary constraint.
    This helper leaves the existing physical oracle unmodified.
    """
    sites = sorted(set((Position.coerce(p).x, Position.coerce(p).y) for p in stations))
    if not sites or not math.isfinite(arena_radius) or arena_radius <= 0:
        raise ValueError("nonempty stations and positive finite arena radius required")
    candidates = [(0., 0.), (arena_radius, 0.), (-arena_radius, 0.),
                  (0., arena_radius), (0., -arena_radius)]
    radius2 = arena_radius**2
    for ax, ay in sites:
        norm = math.hypot(ax, ay)
        if norm > 1e-12:
            candidates.append((-arena_radius*ax/norm, -arena_radius*ay/norm))
    for i, (ax, ay) in enumerate(sites):
        for j in range(i+1, len(sites)):
            bx, by = sites[j]
            ux, uy = bx-ax, by-ay
            norm2 = ux*ux+uy*uy
            if norm2 <= 1e-20:
                continue
            rhs = ux*(ax+bx)/2+uy*(ay+by)/2
            fx, fy = rhs*ux/norm2, rhs*uy/norm2
            rest = radius2-fx*fx-fy*fy
            if rest >= -1e-7:
                scale = math.sqrt(max(0., rest)/norm2)
                candidates.extend(((fx-uy*scale, fy+ux*scale), (fx+uy*scale, fy-ux*scale)))
            for cx, cy in sites[j+1:]:
                vx, vy = cx-ax, cy-ay
                determinant = ux*vy-uy*vx
                if determinant == 0.:
                    continue
                b1, b2 = norm2/2, (vx*vx+vy*vy)/2
                x = ax+(b1*vy-uy*b2)/determinant
                y = ay+(ux*b2-b1*vx)/determinant
                if x*x+y*y <= radius2+1e-6:
                    candidates.append((x, y))
    value, witness = max((min((x-a)**2+(y-b)**2 for a, b in sites), (x, y))
                         for x, y in candidates)
    return CoverWitness(math.sqrt(value), Position(*witness))


def _fraction_point(point):
    return Fraction(point.x), Fraction(point.y)


def necessary_witness(point, fixed, radius, arena_radius=1800.):
    """Return an exactly checked rational witness or None, never a fake cut."""
    point = Position.coerce(point)
    arena2 = Fraction(arena_radius)**2
    for _ in range(8):
        x, y = _fraction_point(point)
        if x*x+y*y <= arena2:
            break
        scale = math.nextafter(arena_radius/math.hypot(point.x, point.y), 0.)
        point = Position(point.x*scale, point.y*scale)
    else:
        return None
    radius2 = Fraction(radius)**2
    for station in fixed:
        a, b = _fraction_point(station)
        if (x-a)**2+(y-b)**2 <= radius2:
            return None
    return point


def _finite_projection(centers, current, radius, incumbent):
    """Finite exact-arithmetic projection candidates; float feasibility only."""
    points = tuple(dict.fromkeys(centers))
    candidates = [incumbent, current]
    for center in points:
        length = current.distance_to(center)
        if length:
            ratio = radius/length
            candidates.append(Position(center.x+ratio*(current.x-center.x),
                                       center.y+ratio*(current.y-center.y)))
    for i, a in enumerate(points):
        for b in points[i+1:]:
            dx, dy = b.x-a.x, b.y-a.y
            length = math.hypot(dx, dy)
            if length > 2*radius+1e-7:
                continue
            half = length/2
            height = math.sqrt(max(0., (radius-half)*(radius+half)))
            mx, my = a.x+dx/2, a.y+dy/2
            ox, oy = -dy/length*height, dx/length*height
            candidates.append(Position(mx+ox, my+oy))
            candidates.append(Position(mx-ox, my-oy))
    feasible = [p for p in candidates if all(p.distance_to(c) <= radius+1e-7 for c in points)]
    if not feasible:
        return None
    return min(feasible, key=lambda p: current.distance_to(p))


def _sqrt_down(value):
    if value <= 0:
        return 0.
    result = math.sqrt(float(value))
    while Fraction(result)**2 > value:
        result = math.nextafter(result, 0.)
    return result


def _distance_up(first, second):
    ax, ay = _fraction_point(first)
    bx, by = _fraction_point(second)
    squared = (ax-bx)**2+(ay-by)**2
    result = math.sqrt(float(squared))
    while Fraction(result)**2 < squared:
        result = math.nextafter(result, math.inf)
    return result


def witness_dual_lower_bound(centers, current, candidate, radius):
    """Valid distance lower bound for rational inputs via a quadratic dual.

    For any nonnegative multipliers lambda, minimizing the Lagrangian of
    .5*|z-current|^2 and .5*(|z-witness|^2-radius^2)<=0 gives a lower bound.
    Approximate active-set geometry proposes multipliers only; exact Fraction
    evaluation and downward square root validate their numerical bound.
    """
    active = [i for i, c in enumerate(centers) if abs(candidate.distance_to(c)-radius) <= 1e-4]
    proposals = [{}]
    vx, vy = current.x-candidate.x, current.y-candidate.y
    for i in active:
        ax, ay = candidate.x-centers[i].x, candidate.y-centers[i].y
        norm2 = ax*ax+ay*ay
        if norm2:
            lam = (vx*ax+vy*ay)/norm2
            if math.isfinite(lam) and lam > 0:
                proposals.append({i: lam})
    for k, i in enumerate(active):
        ax, ay = candidate.x-centers[i].x, candidate.y-centers[i].y
        for j in active[k+1:]:
            bx, by = candidate.x-centers[j].x, candidate.y-centers[j].y
            determinant = ax*by-ay*bx
            if abs(determinant) <= 1e-12:
                continue
            first, second = (vx*by-vy*bx)/determinant, (ax*vy-ay*vx)/determinant
            if all(math.isfinite(v) and v >= 0 for v in (first, second)):
                proposals.append({i: first, j: second})
    px, py = _fraction_point(current)
    r2 = Fraction(radius)**2
    best_squared, best_weights = Fraction(0), {}
    for weights in proposals:
        lambdas = {i: Fraction(v) for i, v in weights.items()}
        total, bx, by, scalar = Fraction(1), px, py, px*px+py*py
        for i, lam in lambdas.items():
            x, y = _fraction_point(centers[i])
            total += lam
            bx += lam*x
            by += lam*y
            scalar += lam*(x*x+y*y-r2)
        squared = scalar-(bx*bx+by*by)/total
        if squared > best_squared:
            best_squared, best_weights = squared, weights
    return _sqrt_down(best_squared), best_weights


@dataclass(frozen=True)
class TerminalProjection:
    point: Position
    coverage_radius_m: float
    fraction: None
    incoming_upper_m: float
    incoming_lower_m: float
    incoming_gap_m: float | None
    iterations: int
    witness_count: int
    status: str
    witnesses: tuple[Position, ...]
    steps: tuple[dict, ...]
    bound_scope: str = "Incoming distance to feasible final-cover set only; rational witness dual LB and full floating-oracle feasible UB, not Q3 total time"


def project_terminal_cover(fixed, current, incumbent, *, radius=1000.-1e-5,
                           arena_radius=1800., maximum_calls=64, gap_tolerance_m=.01):
    """Improve a certified incumbent using <=64 whole-domain oracle queries."""
    if type(maximum_calls) is not int or not 1 <= maximum_calls <= 64:
        raise ValueError("maximum_calls must be integer in [1,64]")
    if (isinstance(radius, bool) or not math.isfinite(radius) or radius <= 0
            or not math.isfinite(arena_radius) or arena_radius <= 0
            or not math.isfinite(gap_tolerance_m) or gap_tolerance_m <= 0):
        raise ValueError("invalid geometric limits")
    fixed = tuple(Position.coerce(p) for p in fixed)
    current, incumbent = Position.coerce(current), Position.coerce(incumbent)
    original = cover_witness(fixed+(incumbent,), arena_radius)
    if original.radius_m > radius:
        raise ValueError("incumbent is not certified by full coverage oracle")
    best, coverage, upper = incumbent, original.radius_m, _distance_up(current, incumbent)
    lower, witnesses, steps, calls, status = 0., [], [], 1, "budget_exhausted"
    # Reserve no fictitious feasibility credit: every improved point must pass
    # the entire domain oracle. A near-feasible relaxation never replaces ray.
    while calls < maximum_calls:
        candidate = _finite_projection(witnesses, current, radius, best)
        if candidate is None:
            status = "finite_projection_numerically_unresolved"
            break
        lb, multipliers = witness_dual_lower_bound(witnesses, current, candidate, radius)
        lower = max(lower, lb)
        if lower > upper+1e-7:
            # Signals disagreement with the floating full-domain certificate;
            # do not describe a negative gap as successful convergence.
            status = "lower_upper_numerical_disagreement"
            break
        if upper-lower <= gap_tolerance_m:
            status = "incoming_gap_closed"
            break
        checked = cover_witness(fixed+(candidate,), arena_radius)
        calls += 1
        step = {"candidate": [candidate.x, candidate.y], "coverage_radius_m": checked.radius_m,
                "lower_m": lower, "dual_weights": multipliers, "feasible": checked.radius_m <= radius}
        if checked.radius_m <= radius:
            distance = _distance_up(current, candidate)
            if distance < upper:
                best, coverage, upper = candidate, checked.radius_m, distance
            steps.append(step)
            status = "incoming_gap_closed" if upper-lower <= gap_tolerance_m else "feasible_without_dual_closure"
            break
        if checked.radius_m-radius <= 1e-5 and calls < maximum_calls:
            # A tiny move toward the already-certified incumbent avoids
            # endless boundary chatter. Convexity motivates this safeguard,
            # but only a fresh WHOLE-domain check grants feasibility credit.
            mixed = Position(candidate.x+1e-4*(best.x-candidate.x),
                             candidate.y+1e-4*(best.y-candidate.y))
            mixed_check = cover_witness(fixed+(mixed,), arena_radius)
            calls += 1
            step["safeguard"] = {"point": [mixed.x, mixed.y],
                                 "coverage_radius_m": mixed_check.radius_m}
            if mixed_check.radius_m <= radius and _distance_up(current, mixed) < upper:
                best, coverage, upper = mixed, mixed_check.radius_m, _distance_up(current, mixed)
                if upper-lower <= gap_tolerance_m:
                    steps.append(step)
                    status = "incoming_gap_closed_after_certified_safeguard"
                    break
        witness = necessary_witness(checked.point, fixed, radius, arena_radius)
        if witness is None:
            steps.append(step)
            status = "violating_witness_not_exactly_necessary"
            break
        if witness in witnesses:
            steps.append(step)
            status = "repeated_witness_or_boundary_roundoff"
            break
        witnesses.append(witness)
        step["added_witness"] = [witness.x, witness.y]
        steps.append(step)
    gap = None if status == "lower_upper_numerical_disagreement" else max(0., upper-lower)
    return TerminalProjection(best, coverage, None, upper, lower, gap,
                              calls, len(witnesses), status, tuple(witnesses), tuple(steps))
