"""Bound a declared frozen task route while enforcing an executed prefix.

The returned bounds apply only to fixed points and supplied service costs.
Neither unknown sources nor subsequent localization feedback is modelled.
"""

from dataclasses import replace
import time

from simulator_client.state import Position
from .state_route import solve_state_route


def solve_prefixed_route(tasks, start, prefix, *, scan_source_s=6.0,
                         max_expansions=100):
    tasks, prefix = tuple(tasks), tuple(prefix)
    if (len(tasks) > 22 or len(set(prefix)) != len(prefix)
            or any(type(i) is not int or not 0 <= i < len(tasks) for i in prefix)):
        raise ValueError("prefix must contain distinct valid task indices")
    # Validate all task fields and parameters through the public finite solver,
    # including tasks that the prefix removes from the suffix problem.
    for task in tasks:
        solve_state_route((task,), start, scan_source_s=scan_source_s,
                          max_expansions=0)
    began = time.perf_counter()
    previous, prefix_cost = Position.coerce(start), 0.0
    remaining_sources = sum(task.is_source for task in tasks)
    for index in prefix:
        task = tasks[index]
        point = Position.coerce(task.position)
        prefix_cost += previous.distance_to(point) / 5.0 + task.service_s
        if task.is_source:
            remaining_sources -= 1
        else:
            prefix_cost += scan_source_s * remaining_sources
        previous = point
    rest = tuple(i for i in range(len(tasks)) if i not in prefix)
    result = solve_state_route(tuple(tasks[i] for i in rest), previous,
                               scan_source_s=scan_source_s,
                               max_expansions=max_expansions)
    return replace(result, order=prefix + tuple(rest[i] for i in result.order),
                   cost_s=prefix_cost + result.cost_s,
                   lower_bound_s=prefix_cost + result.lower_bound_s,
                   runtime_s=time.perf_counter() - began)
