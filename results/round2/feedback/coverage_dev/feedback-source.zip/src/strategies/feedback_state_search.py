"""After real feedback, insert one cover and immediately resume its source.

This is a bounded option interruption with an explicit resumption commitment,
not unrestricted global preemption. Frozen-route bounds justify only the
proxy comparison; real elapsed-time improvement needs paired experiments.
"""

from planning.prefixed_state_route import solve_prefixed_route
from planning.state_route import RouteTask

from .relocating_state_search import RelocatingStateSearch


class FeedbackStateSearch(RelocatingStateSearch):
    def __init__(self, client, max_actions, max_active_probes, config, enabled):
        super().__init__(client, max_actions, max_active_probes, config, True)
        self.feedback_enabled = enabled
        self.active_used = {}
        self.interrupted = set()
        self.feedback_log = []
        self.feedback_skipped = {}
        self.feedback_expanded = 0
        self.report.strategy_parameters.update({
            "feedback_cover_insertion": enabled,
            "feedback_log": self.feedback_log,
            "feedback_skipped": self.feedback_skipped,
            "feedback_active_used": self.active_used,
            "feedback_limits": {"interruptions_per_source": 1,
                                "inserted_covers_per_interruption": 1,
                                "minimum_gain_s": 10.0,
                                "switch_reserve_s": 2.0,
                                "expansions_per_route": 100,
                                "total_expansions": 6000},
            "feedback_scope": "Frozen A-first lower bound versus cover-B,A feasible upper bound; both include every current task. Only B then immediate A is committed, no Q3 nondegradation guarantee.",
            "feedback_scan_proxy_s": 6.0,
            "feedback_progress": "No additional active probes; per-source lifetime active budget; original certified clear and optical fallback; one finite original coverage scan per interruption.",
        })

    def _has_certificate(self, channel):
        region = self.regions.get(channel)
        return (channel in self.near_points or
                bool(region and region.vertices and region.enclosing_disk().radius <= 19.9))

    def _next_probe(self, channel, index):
        if not self.feedback_enabled:
            return super()._next_probe(channel, index)
        used = self.active_used.get(channel, 0)
        if used >= self.max_active_probes:
            return None  # Original _resolve now reaches optical fallback.
        return super()._next_probe(channel, used)

    def _perform(self, action, position, channel, phase):
        response = super()._perform(action, position, channel, phase)
        if self.feedback_enabled and action == "measure" and phase == "active_localization":
            # The superclass has already appended this response and updated all
            # real geometry. Nested scans append their own later observations;
            # the returned response is never installed again by _resolve.
            self.active_used[channel] = self.active_used.get(channel, 0) + 1
            self._try_insert_cover(channel)
        return response

    def _try_insert_cover(self, channel):
        reason = None
        if channel in self.interrupted:
            reason = "already_interrupted"
        elif channel in self.cleared or self._has_certificate(channel):
            reason = "clear_certificate_ready"
        elif self.active_used[channel] >= self.max_active_probes:
            reason = "active_budget_exhausted"
        elif not self.remaining_covers:
            reason = "no_remaining_cover"
        elif self.state_config.stop_discovery_at_16 and len(self.detected | self.cleared) == 16:
            reason = "discovery_complete_at_16"
        if reason is not None:
            self.feedback_skipped[reason] = self.feedback_skipped.get(reason, 0) + 1
            return
        point, record = self._choose_cover(channel)
        self.feedback_log.append(record)
        if point is None:
            return
        # No call to _next_task or relocation is made here. The remaining list
        # is exactly the parent's live list; remove B only after its full scan.
        self.interrupted.add(channel)
        record["scan_start_action_count"] = len(self.report.action_history)
        self._scan(point)
        self.remaining_covers.remove(point)
        if not self.remaining_covers:
            self.report.coverage_complete = True
        record["scan_end_action_count"] = len(self.report.action_history)
        record["resume_primary_channel"] = channel
        record["after_scan_certified"] = self._has_certificate(channel)
        record["remaining_after"] = [[p.x, p.y] for p in self.remaining_covers]
        # Return to the SAME _resolve stack frame, so A immediately receives
        # its certificate check or next probe. New discoveries cannot defer it.

    def _choose_cover(self, channel):
        current = self.client.state.position
        covers = list(self.remaining_covers)
        sources = [(c, target) for c in sorted(self.detected - self.cleared - self.blocked)
                   if (target := self._target(c)) is not None]
        primary = next(i + len(covers) for i, (c, _) in enumerate(sources) if c == channel)
        background = max(0, 20 - len(self.cleared) - len(sources))
        tasks = ([RouteTask(p, False, 6.0 * background) for p in covers]
                 + [RouteTask(p, True, 5.0) for _, p in sources])

        def solve(prefix):
            budget = max(0, min(100, 6000 - self.feedback_expanded))
            result = solve_prefixed_route(tasks, current, prefix,
                                         scan_source_s=6.0, max_expansions=budget)
            self.feedback_expanded += result.expanded
            return result

        keep = solve((primary,))
        record = {"channel": channel, "after_action_count": len(self.report.action_history),
                  "active_probes_used": self.active_used[channel],
                  "position": [current.x, current.y],
                  "remaining_before": [[p.x, p.y] for p in covers],
                  "source_channels": [c for c, _ in sources],
                  "source_targets": [[p.x, p.y] for _, p in sources],
                  "keep_cost_s": keep.cost_s, "keep_lower_bound_s": keep.lower_bound_s,
                  "keep_order": list(keep.order), "candidates": [], "inserted": False}
        best = None
        for index, point in enumerate(covers):
            alternate = solve((index, primary))
            # Using keep's LOWER bound rejects a false improvement caused only
            # by an unfinished keep search. These remain model-only bounds.
            certified_proxy_gain = keep.lower_bound_s - alternate.cost_s
            record["candidates"].append({"cover_index": index,
                "cost_s": alternate.cost_s, "lower_bound_s": alternate.lower_bound_s,
                "order": list(alternate.order), "proxy_gain_s": keep.cost_s - alternate.cost_s,
                "bounded_proxy_gain_s": certified_proxy_gain})
            if certified_proxy_gain > 12.0 and (best is None or alternate.cost_s < best[0]):
                best = (alternate.cost_s, point, index, certified_proxy_gain)
        record["total_feedback_expanded"] = self.feedback_expanded
        if best is None:
            record["reason"] = "no_frozen_bound_improvement_above_12s"
            return None, record
        _, point, index, gain = best
        record.update(inserted=True, chosen_cover_index=index,
                      chosen_position=[point.x, point.y], bounded_proxy_gain_s=gain)
        return point, record


def run_feedback_state_search(client, *, problem=3, max_actions=10000,
                              max_active_probes=6, config=None, enabled=True):
    if problem != 3:
        raise ValueError("feedback cover insertion is Q3 only")
    if type(enabled) is not bool:
        raise ValueError("enabled must be boolean")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("max_active_probes must be in [0,30]")
    return FeedbackStateSearch(client, max_actions, max_active_probes, config, enabled).run()
