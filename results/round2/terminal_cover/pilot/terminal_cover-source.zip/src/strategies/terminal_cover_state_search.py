"""Reposition the final discovery visit when no observed source remains.

The decision uses the public count cap and executed full scans only. Unknown
sources can still exist: all uncleared channels are really scanned at the new
site, and newly found sources go through the unchanged localization policy.
"""
from planning.coverage_relocation import CoverageOracle, CoverageOracleBudget, feasible_ray_point
from .relocating_state_search import RelocatingStateSearch


class TerminalCoverSearch(RelocatingStateSearch):
    def __init__(self, client, max_actions, max_active_probes, config, enabled):
        super().__init__(client, max_actions, max_active_probes, config, True)
        self.terminal_enabled = enabled
        self.terminal_log = []
        self.terminal_oracle = CoverageOracle(64)
        self.report.strategy_parameters.update({
            "terminal_cover_enabled": enabled,
            "terminal_cover_log": self.terminal_log,
            "terminal_cover_scope": "One remaining cover and all observed sources cleared; ray projection toward current position; full-disk certificate, not a claim that no unknown source exists",
        })

    def _next_task(self, remaining):
        if (self.terminal_enabled and len(remaining) == 1
                and not self.detected - self.cleared
                and len(self.detected | self.cleared) < 16):
            old, current = remaining[0], self.client.state.position
            log = {"after_actual_action_count": len(self.report.action_history),
                   "current": [current.x, current.y], "old_position": [old.x, old.y],
                   "executed_stations": [[p.x, p.y] for p in self.discovery_stations],
                   "observed_source_count": len(self.detected | self.cleared),
                   "relocated": False}
            try:
                replacement = feasible_ray_point(tuple(self.discovery_stations), old, current,
                    oracle=self.terminal_oracle)
                saved = (current.distance_to(old) - current.distance_to(replacement.point)) / 5
                if saved > 1e-5:
                    remaining[0] = replacement.point
                    self.report.coverage_points = [[p.x, p.y] for p in self.discovery_stations + remaining]
                    log.update(relocated=True, new_position=[replacement.point.x, replacement.point.y],
                        guaranteed_incoming_saved_s=saved,
                        certified_coverage_radius_m=replacement.coverage_radius_m,
                        ray_fraction=replacement.fraction)
            except (CoverageOracleBudget, ValueError) as error:
                # Retain the original known-feasible plan if a new certificate
                # cannot be obtained. This does not suppress simulator errors.
                log["fallback"] = type(error).__name__ + ": " + str(error)
            self.terminal_log.append(log)
        return super()._next_task(remaining)


def run_terminal_cover_state_search(client, *, problem=3, max_actions=10000,
                                    max_active_probes=6, config=None, enabled=True):
    if problem != 3:
        raise ValueError("Terminal cover repositioning is Q3 only")
    if type(enabled) is not bool:
        raise ValueError("enabled must be boolean")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("max_active_probes must be integer in [0,30]")
    return TerminalCoverSearch(client, max_actions, max_active_probes, config, enabled).run()
