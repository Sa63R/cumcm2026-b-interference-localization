"""Q3 fixed-representative nested observation planning above frozen v1.

Only observed history enters the conditional sampler. Worlds are passed to the
internal observation generator; all macro task choices use public snapshots.
Root-MC and depth-two arms share candidates/model/v1 tail/compute ceilings.
"""
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import random
import statistics
import time

from planning.conditional_mc import choose_then_evaluate, finite_cost
from .relocating_state_search import RelocatingStateSearch


@dataclass(frozen=True)
class ObservationTreeConfig:
    depth: int = 2
    evaluation_mode: str = "conditional_resample"
    candidates: int = 3
    predictive_worlds: int = 16
    representatives: int = 2
    conditional_worlds: int = 16
    root_evaluation_worlds: int = 8
    training_worlds: int = 2
    evaluation_worlds: int = 2
    max_searches: int = 3
    max_tail_evaluations: int = 48
    max_generated_actions: int = 40000
    decision_seconds: float = 90.0
    total_seconds: float = 270.0
    minimum_gain_seconds: float = 10.0
    standard_error_penalty: float = 0.5
    seed: int = 2026091121

    @classmethod
    def parse(cls, values):
        if values is not None and not isinstance(values, dict):
            raise ValueError("tree_config must be a dictionary")
        result = cls(**(values or {}))
        if result.evaluation_mode not in ("conditional_resample", "coupled_predictive"):
            raise ValueError("Invalid evaluation_mode")
        integer_limits = {"depth": (1, 2), "candidates": (2, 3), "predictive_worlds": (8, 64),
                          "representatives": (2, 4), "conditional_worlds": (8, 32),
                          "root_evaluation_worlds": (2, 16),
                          "training_worlds": (2, 8), "evaluation_worlds": (2, 8),
                          "max_searches": (0, 12), "max_tail_evaluations": (1, 256),
                          "max_generated_actions": (1, 200000), "seed": (0, 2**63-1)}
        for name, (low, high) in integer_limits.items():
            value = getattr(result, name)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"Invalid {name}")
        for name, high in (("decision_seconds", 120), ("total_seconds", 600),
                           ("minimum_gain_seconds", 10000), ("standard_error_penalty", 10)):
            value = getattr(result, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= high:
                raise ValueError(f"Invalid {name}")
        if result.training_worlds + result.evaluation_worlds > result.conditional_worlds:
            raise ValueError("Training and evaluation need distinct conditional draws")
        if (result.conditional_worlds % 2 or result.training_worlds > result.conditional_worlds // 2
                or result.evaluation_worlds > result.conditional_worlds // 2):
            raise ValueError("Separate conditional draw streams require equal, sufficient pool sizes")
        if result.root_evaluation_worlds % 2 or result.root_evaluation_worlds > result.conditional_worlds:
            raise ValueError("Root evaluation uses equally sized subsets of both independent streams")
        return result


class PlanningRefused(RuntimeError):
    pass


def task_record(task):
    return {"kind": task[0], "channel": task[1], "position": [task[2].x, task[2].y]}


def observation_digest(history):
    keys = ("action", "channel", "position", "result", "bearing_deg", "virtual_time_s")
    payload = [{key: event.get(key) for key in keys} for event in history]
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def macro_identity(record):
    # Source target coordinates are route proxies; _resolve acts on channel.
    return (("source", record["channel"]) if record["kind"] == "source"
            else ("cover", *record["position"]))


def draw_diagnostics(worlds, cleared):
    signatures = [tuple((source.channel, source.x, source.y) for source in world.sources
                        if source.channel not in cleared) for world in worlds]
    return {"draws": len(worlds), "equal_draw_weight_ess": len(worlds),
            "distinct_active_position_worlds": len(set(signatures)),
            "scope": "Hypothesis draws only; equal-weight ESS does not certify accuracy or independent observed outcomes"}


def choose_from_training(actions, training_worlds, evaluate):
    """Choose using training only; no predictive evaluation world is accepted."""
    if not actions or not training_worlds:
        raise ValueError("Nonempty actions and conditional training draws required")
    costs = tuple(tuple(finite_cost(evaluate(action, world)) for world in training_worlds)
                  for action in actions)
    index = min(range(len(actions)), key=lambda i: (statistics.fmean(costs[i]), i))
    return index, costs


def macro_candidates(policy, remaining, baseline, maximum):
    if baseline is None:
        return []
    current = policy.client.state.position
    sources = [("source", channel, target)
               for channel in sorted(policy.detected - policy.cleared - policy.blocked)
               if (target := policy._target(channel)) is not None]
    sources.sort(key=lambda task: (current.distance_to(task[2]), task[1]))
    covers = [("cover", None, point) for point in remaining]
    if policy.state_config.stop_discovery_at_16 and len(policy.detected | policy.cleared) == 16:
        covers = []
    covers.sort(key=lambda task: (current.distance_to(task[2]), task[2].x, task[2].y))
    choices = [baseline]
    # Include the other task family before filling with nearby alternatives.
    preferred = (covers + sources if baseline[0] == "source" else sources + covers)
    for task in preferred:
        if task not in choices:
            choices.append(task)
        if len(choices) >= maximum:
            break
    return choices


class ObservationTreeStateSearch(RelocatingStateSearch):
    def __init__(self, client, max_actions, max_active_probes, config, tree_config, enabled):
        super().__init__(client, max_actions, max_active_probes, config, True)
        self.observation_config = ObservationTreeConfig.parse(tree_config)
        self.observation_enabled = enabled
        self.observation_log = []
        self.observation_seconds = 0.0
        self.report.strategy_parameters.update(observation_tree=asdict(self.observation_config),
            observation_tree_enabled=enabled, observation_tree_log=self.observation_log,
            observation_tree_model="finite conditional position pools; fixed-key uniform error; undiscounted complete v1 tail",
            observation_tree_algorithm="fixed-predictive-representative nested conditional Monte Carlo, not full POMCPOW")

    def _next_task(self, remaining):
        baseline = super()._next_task(remaining)
        cfg = self.observation_config
        if not self.observation_enabled or baseline is None or len(self.observation_log) >= cfg.max_searches:
            return baseline
        tasks = macro_candidates(self, remaining, baseline, cfg.candidates)
        if len(tasks) < 2:
            return baseline
        available = min(cfg.decision_seconds, cfg.total_seconds - self.observation_seconds)
        real_left = getattr(self.client, "remaining_real_time_s", None)
        if real_left is not None:
            available = min(available, real_left - 10.0)
        if available <= 0:
            return baseline
        from .observation_continuation import capture_v1, V1Continuation
        from .q3_observation_likelihood import sample_conditioned_worlds
        from .q3_belief import BeliefSamplingError
        from simulation.q3_branch import make_q3_branch

        started, search_index = time.perf_counter(), len(self.observation_log)
        deadline = started + available
        snapshot = capture_v1(self, remaining, pending_task=baseline)
        record = {"after_actual_action_count": len(self.report.action_history),
                  "virtual_time_s": self.client.state.virtual_time_s,
                  "baseline": task_record(baseline), "selected": task_record(baseline),
                  "status": "baseline", "tail_evaluations": 0, "generated_actions": 0,
                  "conditional_nodes": 0, "second_layer_comparisons": 0,
                  "second_layer_changes": 0, "candidates": []}
        coupled = cfg.evaluation_mode == "coupled_predictive"
        if coupled:
            record.update(evaluation_mode=cfg.evaluation_mode, tail_evaluations_completed=0,
                          tail_completion_log=[], predictive_representatives=cfg.representatives,
                          evaluation_scope="Same predictive world after its full observed macro; independent conditional training only; no fresh evaluation draw or posterior ESS claim")
        self.observation_log.append(record)
        seed = cfg.seed + 1000003 * search_index

        def check_budget(tail=False):
            if time.perf_counter() >= deadline:
                raise PlanningRefused("compute_deadline")
            if record["generated_actions"] >= cfg.max_generated_actions:
                raise PlanningRefused("generated_action_budget")
            if tail and record["tail_evaluations"] >= cfg.max_tail_evaluations:
                raise PlanningRefused("tail_evaluation_budget")

        def new_continuation(state, world):
            check_budget()
            client = make_q3_branch(world, state.public_state, state.history)
            continuation = V1Continuation(state, client, deadline=deadline,
                action_limit=cfg.max_generated_actions - record["generated_actions"])
            return client, continuation

        def evaluate_tail(state, world, task=None, *, context=None):
            check_budget(tail=True)
            client, continuation = new_continuation(state, world)
            record["tail_evaluations"] += 1
            completion = None
            if coupled:
                completion = {"index":record["tail_evaluations"]-1, "status":"started",
                              "start_virtual_time_s":state.public_state.virtual_time_s,
                              "task":task_record(task) if task else None, **(context or {})}
                record["tail_completion_log"].append(completion)
            try:
                with client:
                    if task is not None:
                        continuation.step(task)
                    report = continuation.finish()
                if (not report.completion_certified_under_model or report.error or report.exit_error
                        or client.state.session != "exited"):
                    raise PlanningRefused("incomplete_simulated_tail:" + str(report.completion_reason))
                if any(event["action"] == "clear" and event["result"] != "success"
                       for event in report.action_history[len(state.history):]):
                    raise PlanningRefused("failed_clear_in_simulated_tail")
                cost = finite_cost(report.virtual_time_s - state.public_state.virtual_time_s)
                if coupled:
                    record["tail_evaluations_completed"] += 1
                    completion.update(status="completed",cost_s=cost)
                return cost
            finally:
                record["generated_actions"] += max(0, len(continuation.report.action_history) - len(state.history))
                if completion is not None and completion["status"] == "started":
                    completion["status"] = "not_completed"

        try:
            root = sample_conditioned_worlds(snapshot.history, count=cfg.predictive_worlds,
                                            seed=seed, deadline=deadline, min_support=4)
            record["root_belief"] = root.diagnostics
            rng = random.Random(seed + 17)
            representatives = rng.choices(root.worlds, weights=root.weights, k=cfg.representatives)
            total_costs = []
            for task_index, task in enumerate(tasks):
                values, nodes = [], []
                candidate_record = None
                if coupled:
                    # New-mode diagnostic retention only: keep partial work
                    # if the current candidate later exhausts a budget.
                    candidate_record = {**task_record(task), "predictive_costs_s":values,
                                        "nodes":nodes, "status":"in_progress"}
                    record["candidates"].append(candidate_record)
                for node_index, representative in enumerate(representatives):
                    check_budget()
                    client, continuation = new_continuation(snapshot, representative)
                    try:
                        with client:
                            first = continuation.step(task)
                            inner_baseline, child_snapshot = continuation.prepare_decision()
                            inner_tasks = macro_candidates(continuation, child_snapshot.remaining,
                                                           inner_baseline, cfg.candidates)
                    finally:
                        record["generated_actions"] += max(0, len(continuation.report.action_history) - len(snapshot.history))
                    initial_cost = finite_cost(child_snapshot.public_state.virtual_time_s - snapshot.public_state.virtual_time_s)
                    node = {"first_cost_s": initial_cost,
                            "observation_count": len(child_snapshot.history) - len(snapshot.history),
                            "observation_sha256": observation_digest(child_snapshot.history[len(snapshot.history):]),
                            "inner_baseline": task_record(inner_baseline) if inner_baseline else None}
                    nodes.append(node)
                    if coupled:
                        node.update(status="in_progress",representative_index=node_index,
                            actual_training_draws=0,actual_evaluation_draws=0,
                            planned_evaluation_worlds=1,
                            fresh_conditional_evaluation_draws=0,
                            evaluation_is_independent_draw=False,
                            evaluation_origin="same_predictive_representative",
                            evaluation_used_support={"evaluated_worlds":0,
                                "scope":"One previously drawn predictive world conditioned by its generated observation; not a fresh conditional sample; no ESS guarantee"})
                        context = {"first_action_index":task_index,"representative_index":node_index}
                        if inner_baseline is None or cfg.depth == 1 or len(inner_tasks) < 2:
                            value = evaluate_tail(child_snapshot,representative,
                                context={**context,"role":"coupled_fixed_v1_evaluation"})
                            node.update(status="coupled_fixed_v1_tail",coupled_costs_s=[value],value_s=value,
                                        actual_evaluation_draws=1)
                            node["evaluation_used_support"]["evaluated_worlds"] = 1
                        else:
                            condition_seed = seed + 1009 * (task_index + 1) + 9176 * (node_index + 1)
                            training = sample_conditioned_worlds(child_snapshot.history,count=cfg.conditional_worlds//2,
                                seed=condition_seed,deadline=deadline,min_support=4)
                            node["belief"] = {"training_pool":training.diagnostics}
                            if any(abs(w-1/len(training.worlds)) > 1e-10 for w in training.weights):
                                raise PlanningRefused("conditional_sampler_requires_equal_weight_draws")
                            record["conditional_nodes"] += 1
                            train_used = training.worlds[:cfg.training_worlds]
                            node.update(planned_training_draws=len(train_used),
                                conditional_training_pool_draws=len(training.worlds),
                                unused_training_pool_draws=len(training.worlds)-len(train_used))
                            # The selection function receives only actions and
                            # independent training worlds. Evaluation W is not
                            # a parameter and cannot change the chosen action.
                            chosen, training_costs = choose_from_training(inner_tasks,train_used,
                                lambda action,world:evaluate_tail(child_snapshot,world,action,
                                    context={**context,"role":"conditional_training"}))
                            fixed = inner_tasks[chosen]
                            node.update(selected=task_record(fixed),training_costs_s=training_costs,
                                        status="training_choice_frozen",actual_training_draws=len(train_used),
                                        training_used_support=draw_diagnostics(train_used,child_snapshot.policy_state["cleared"]))
                            record["second_layer_comparisons"] += 1
                            record["second_layer_changes"] += int(chosen != 0)
                            value = evaluate_tail(child_snapshot,representative,fixed,
                                context={**context,"role":"coupled_policy_evaluation"})
                            node.update(status="coupled_conditional_action_evaluated",
                                        coupled_costs_s=[value],value_s=value,actual_evaluation_draws=1)
                            node["evaluation_used_support"]["evaluated_worlds"] = 1
                    elif inner_baseline is None:
                        value = evaluate_tail(child_snapshot, representative)
                        node.update(status="terminal_or_no_alternative", value_s=value)
                    else:
                        condition_seed = seed + 1009 * (task_index + 1) + 9176 * (node_index + 1)
                        training = sample_conditioned_worlds(child_snapshot.history, count=cfg.conditional_worlds // 2,
                            seed=condition_seed, deadline=deadline, min_support=4)
                        evaluation = sample_conditioned_worlds(child_snapshot.history, count=cfg.conditional_worlds // 2,
                            seed=condition_seed + 32452843, deadline=deadline, min_support=4)
                        node["belief"] = {"training_pool": training.diagnostics, "evaluation_pool": evaluation.diagnostics}
                        # Each returned world is an equal-weight conditional
                        # draw. Pool support is not the sample size of the
                        # small subsets actually evaluated below.
                        if any(abs(w - 1/len(pool.worlds)) > 1e-10
                               for pool in (training, evaluation) for w in pool.weights):
                            raise PlanningRefused("conditional_sampler_requires_equal_weight_draws")
                        record["conditional_nodes"] += 1
                        if cfg.depth == 1 or len(inner_tasks) < 2:
                            used = (training.worlds[:cfg.root_evaluation_worlds // 2]
                                    + evaluation.worlds[:cfg.root_evaluation_worlds // 2])
                            costs = [evaluate_tail(child_snapshot, world) for world in used]
                            value = statistics.fmean(costs)
                            node.update(status="fixed_v1_tail", costs_s=costs, value_s=value,
                                        actual_training_draws=0, actual_evaluation_draws=len(costs),
                                        evaluation_used_support=draw_diagnostics(used, child_snapshot.policy_state["cleared"]),
                                        unused_conditional_draws=cfg.conditional_worlds-len(costs))
                        else:
                            train_used, eval_used = training.worlds[:cfg.training_worlds], evaluation.worlds[:cfg.evaluation_worlds]
                            choice = choose_then_evaluate(inner_tasks,
                                train_used, eval_used,
                                lambda action, world: evaluate_tail(child_snapshot, world, action))
                            value = choice.value
                            record["second_layer_comparisons"] += 1
                            record["second_layer_changes"] += int(choice.index != 0)
                            node.update(status="conditional_action_evaluated", selected=task_record(inner_tasks[choice.index]),
                                training_costs_s=choice.training_costs, heldout_costs_s=choice.evaluation_costs, value_s=value,
                                actual_training_draws=cfg.training_worlds, actual_evaluation_draws=cfg.evaluation_worlds,
                                training_used_support=draw_diagnostics(train_used, child_snapshot.policy_state["cleared"]),
                                evaluation_used_support=draw_diagnostics(eval_used, child_snapshot.policy_state["cleared"]),
                                unused_conditional_draws=cfg.conditional_worlds-cfg.training_worlds-cfg.evaluation_worlds)
                    values.append(initial_cost + value)
                total_costs.append(values)
                completed_candidate = {**task_record(task), "predictive_costs_s": values,
                    "mean_cost_s": statistics.fmean(values), "nodes": nodes,
                    "distinct_effective_observations": len({n["observation_sha256"] for n in nodes
                        if n["status"] in ("conditional_action_evaluated","coupled_conditional_action_evaluated")}),
                    "distinct_conditional_actions": len({macro_identity(n["selected"]) for n in nodes
                        if n["status"] in ("conditional_action_evaluated","coupled_conditional_action_evaluated")})}
                if coupled:
                    candidate_record.update(completed_candidate,status="completed")
                else:
                    record["candidates"].append(completed_candidate)
            selected, best_margin = 0, 0.0
            for index in range(1, len(tasks)):
                gains = [a - b for a, b in zip(total_costs[0], total_costs[index])]
                mean = statistics.fmean(gains)
                se = statistics.stdev(gains) / math.sqrt(len(gains))
                margin = mean - cfg.minimum_gain_seconds - cfg.standard_error_penalty * se
                record["candidates"][index].update(paired_gain_s=mean, paired_standard_error_s=se,
                                                    heuristic_selection_margin_s=margin)
                if margin > best_margin:
                    selected, best_margin = index, margin
            record.update(status="changed" if selected else "evaluated_baseline",
                          selected=task_record(tasks[selected]),
                          mechanism_active=cfg.depth == 2 and any(
                              item["distinct_effective_observations"] >= 2 for item in record["candidates"]))
            return tasks[selected]
        except (PlanningRefused, BeliefSamplingError, ValueError) as error:
            record.update(status="fallback", reason=f"{type(error).__name__}: {error}", mechanism_active=False)
            if getattr(error, "diagnostics", None):
                record["failure_diagnostics"] = error.diagnostics
            return baseline
        finally:
            elapsed = time.perf_counter() - started
            record["planning_runtime_s"] = elapsed
            self.observation_seconds += elapsed


def run_observation_tree_state_search(client, *, problem=3, max_actions=10000,
        max_active_probes=6, config=None, tree_config=None, enabled=True):
    if problem != 3 or type(enabled) is not bool:
        raise ValueError("Observation tree is Q3 only; enabled must be boolean")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("Invalid max_active_probes")
    return ObservationTreeStateSearch(client, max_actions, max_active_probes,
                                     config, tree_config, enabled).run()
