"""Declared Q3 observation model and bounded finite-pool conditioning.

This is a RESEARCH model, not the official posterior. The prior is uniform
N in 10..16, uniform N-subsets of 20 channels, independent area-uniform disk
positions and uniform radii in [1000,1500]. Distinct physical measurement keys
have independent continuous uniform [-1,1] errors; each key keeps its error.
The local engine's centidegree Q function defines the observation likelihood.

Conservative polygons propose positions uniformly. Importance weights are
radius-interval length / 500 times the product of unique bearing likelihoods.
Mandatory-channel evidence additionally includes proposal-area / prior-area;
every mandatory channel's normalization cancels from comparisons of N/subsets.
Optional channels with negative observations use exactly 4096 prior proposals,
including ALL failed proposals, without support-dependent early stopping.
The resulting self-normalized finite pools approximate conditioning, including
Monte Carlo error in optional existence evidence. They are not certificates.
Only mandatory conditional pools may extend their first batch when support is
low. Their recorded evidence can have stopping bias, but is never used in the
N/subset comparison. Fixed optional proposal counts remove that stopping bias
from optional evidence, not finite-sample or self-normalization error from the
overall approximate posterior.

Returned worlds retain cleared sources; their fresh seeds represent FUTURE
errors only. A branch simulator must anchor the supplied historical readings.
Equal returned weights mean draws from these conditioned pools, not evidence
to be multiplied by the entire history a second time. Support diagnostics
ignore fresh seeds/radii and already-cleared source positions.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
import random

from simulation.cases import Scenario, Source
from simulation.engine import LocalResearchSimulator
from .q3_belief import (
    BeliefSamplingError, BeliefSamplingTimeout, _absence_proven,
    _check_deadline, _history_by_channel, _number, _polygon_sampler,
    _prior_position, _proposal_polygon, _radius_interval,
)


class BeliefLowSupport(BeliefSamplingError):
    """The bounded approximation cannot establish sufficient position support."""

    def __init__(self, message, diagnostics=None):
        super().__init__(message)
        self.diagnostics = diagnostics or {}


@dataclass(frozen=True)
class ConditionedWorlds:
    worlds: tuple[Scenario, ...]
    weights: tuple[float, ...]
    diagnostics: dict


@dataclass(frozen=True)
class _LikelihoodPool:
    candidates: tuple[tuple[float, float, float, float], ...] | None
    weights: tuple[float, ...]
    log_evidence: float
    diagnostics: dict


def quantized_bearing_likelihood(theta_deg, reported_deg):
    """Lebesgue mass of Q(theta, Uniform[-1,1]) == reported, in O(1).

    Rounding ties have zero mass. Only the reported centidegree and its two
    adjacent pre-round bins can map to this report: the engine adjusts a
    rounded value by at most one centidegree. Interval endpoints are integrated
    analytically; calling Q at each interval's interior handles wrap and its
    explicit 1e-12 final-error tolerance without a second implementation of Q.
    """
    theta = _number(theta_deg, "theta_deg") % 360.0
    reported = _number(reported_deg, "reported_deg")
    if not 0.0 <= reported < 360.0:
        raise BeliefSamplingError("reported_deg must be in [0,360)")
    cent = round(reported * 100)
    if reported != (cent % 36000) / 100.0:
        return 0.0
    center = cent + 36000 * round((theta - reported) / 360.0)
    length = 0.0
    for index in (center - 1, center, center + 1):
        middle = index / 100.0 - theta
        lower, upper = max(-1.0, middle - 0.005), min(1.0, middle + 0.005)
        if upper > lower:
            emitted = LocalResearchSimulator._quantize_bearing(theta, (lower + upper) / 2)
            if emitted == reported:
                length += upper - lower
    return min(1.0, max(0.0, length / 2.0))


def _record_key(record):
    return (record["action"], record["channel"], tuple(record["position"]),
            record["result"], record.get("bearing_deg") if record["result"] == "direction" else None)


def history_log_likelihood(world, history, *, prefix_history=(), deadline=None):
    """Log likelihood of NEW effective keys in a complete legal history.

    ``history`` is the full history. ``prefix_history`` must be its semantic
    action-record prefix, not an unrelated conditioning history or suffix.
    All full-history constraints, including prefix consistency with world, are
    checked. Impossible world/history returns -inf; malformed or contradictory
    public histories raise BeliefSamplingError. Repeated exact (channel,x,y)
    keys, including signed-zero variants, do not supply independent evidence.
    """
    if deadline is not None:
        deadline = _number(deadline, "deadline")
    _check_deadline(deadline)
    events, _ = _history_by_channel(history, deadline)
    prefix, _ = _history_by_channel(prefix_history, deadline)
    if len(prefix_history) > len(history) or any(
        _record_key(left) != _record_key(right)
        for left, right in zip(prefix_history, history)
    ):
        raise BeliefSamplingError("prefix_history must be a semantic prefix of the full history")
    if world.problem != 3 or any(source.orientation_deg is not None for source in world.sources):
        raise BeliefSamplingError("Observation model accepts only hypothetical Q3 worlds")
    sources = {source.channel: source for source in world.sources}
    log_probability = 0.0
    for channel, items in events.items():
        _check_deadline(deadline)
        source = sources.get(channel)
        prefix_items = set(prefix[channel])
        for index, item in enumerate(items):
            if index % 32 == 0:
                _check_deadline(deadline)
            if source is None:
                if item.result not in ("no_signal", "no_target_in_range"):
                    return -math.inf
                continue
            distance = math.dist((source.x, source.y), item.position)
            if item.result == "direction":
                if not 5.0 < distance <= source.reception_radius_m:
                    return -math.inf
                theta = math.degrees(math.atan2(source.y - item.position[1],
                                               source.x - item.position[0])) % 360
                probability = quantized_bearing_likelihood(theta, item.bearing)
                if probability <= 0.0:
                    return -math.inf
                if item not in prefix_items:
                    log_probability += math.log(probability)
            elif item.result == "near":
                if distance > 5.0 or distance > source.reception_radius_m:
                    return -math.inf
            elif item.result == "no_signal":
                if distance <= source.reception_radius_m:
                    return -math.inf
            elif item.result == "success":
                if distance > 20.0:
                    return -math.inf
            elif distance <= 20.0:
                return -math.inf
    _check_deadline(deadline)
    return log_probability


def _logadd(left, right):
    if left == -math.inf:
        return right
    if right == -math.inf:
        return left
    top = max(left, right)
    return top + math.log1p(math.exp(min(left, right) - top))


def _logsum(values):
    total = -math.inf
    for value in values:
        total = _logadd(total, value)
    return total


def _position_ess(candidates, weights):
    by_position = {}
    for point, weight in zip(candidates, weights):
        key = point[:2]
        by_position[key] = by_position.get(key, 0.0) + weight
    total = math.fsum(by_position.values())
    return len(by_position), total * total / math.fsum(w * w for w in by_position.values()) if total else 0.0


def _conditional_pool(events, required, rng, min_support, deadline):
    _check_deadline(deadline)
    if not events:
        return _LikelihoodPool(None, (), 0.0, dict(kind="continuous_prior", position_ess=None,
                                                   distinct_positions=None, proposals=0))
    area_ratio = 1.0
    if required:
        polygon = _proposal_polygon(events, deadline)
        sample = _polygon_sampler(polygon, rng, deadline)
        # The same triangle fan is used by the sampler; all accepted positions
        # are checked against the true disk, since this polygon is outer.
        a = polygon[0]
        area = math.fsum(abs((b[0] - a[0]) * (c[1] - a[1]) -
                             (b[1] - a[1]) * (c[0] - a[0])) / 2
                         for b, c in zip(polygon[1:-1], polygon[2:]))
        area_ratio = area / (math.pi * 1800.0**2)
    else:
        sample = lambda: _prior_position(rng)
    candidates, logs, trials = [], [], 0
    directions = [event for event in events if event.result == "direction"]
    batches = (256, 3584) if required else (4096,)
    evidence_sampling = "adaptive_mandatory_conditional_pool" if required else "fixed_4096_prior_proposals"
    for batch in batches:
        for _ in range(batch):
            if trials % 16 == 0:
                _check_deadline(deadline)
            position = sample()
            interval = _radius_interval(position, events)
            trials += 1
            if interval is None:
                continue
            log_weight = math.log((interval[1] - interval[0]) / 500.0)
            for index, item in enumerate(directions):
                if index % 32 == 0:
                    _check_deadline(deadline)
                theta = math.degrees(math.atan2(position[1] - item.position[1],
                                               position[0] - item.position[0])) % 360.0
                mass = quantized_bearing_likelihood(theta, item.bearing)
                if mass <= 0:
                    log_weight = -math.inf
                    break
                log_weight += math.log(mass)
            if log_weight != -math.inf:
                candidates.append((*position, *interval))
                logs.append(log_weight)
        if candidates:
            top = max(logs)
            weights = tuple(math.exp(value - top) for value in logs)
            distinct, ess = _position_ess(candidates, weights)
            if distinct >= min_support and ess >= min_support:
                log_evidence = math.log(area_ratio) + top + math.log(math.fsum(weights)) - math.log(trials)
                return _LikelihoodPool(tuple(candidates), weights, log_evidence, dict(
                    kind="finite_importance_pool", proposals=trials, accepted=len(candidates),
                    distinct_positions=distinct, position_ess=ess, log_evidence=log_evidence,
                    proposal_area_prior_ratio=area_ratio, unique_direction_keys=len(directions),
                    evidence_sampling=evidence_sampling,
                ))
        elif not required and _absence_proven(events, deadline):
            return _LikelihoodPool((), (), -math.inf, dict(
                kind="geometric_absence_certificate", proposals=trials, accepted=0,
                distinct_positions=0, position_ess=0.0, log_evidence=None, zero_evidence=True,
                evidence_sampling=evidence_sampling))
    diagnostics = dict(proposals=trials, accepted=len(candidates),
                       distinct_positions=distinct if candidates else 0,
                       position_ess=ess if candidates else 0.0,
                       evidence_sampling=evidence_sampling)
    raise BeliefLowSupport("Finite likelihood pool has insufficient distinct position support; "
                           "absence is not established", diagnostics)


def _source(channel, pool, rng):
    if pool.candidates is None:
        x, y = _prior_position(rng)
        return Source(channel, x, y, rng.uniform(1000.0, 1500.0))
    x, y, lower, upper = rng.choices(pool.candidates, weights=pool.weights, k=1)[0]
    radius = min(math.nextafter(upper, lower), lower + rng.random() * (upper - lower))
    return Source(channel, x, y, radius)


def sample_conditioned_worlds(history, *, count, seed, deadline=None, min_support=4):
    """Return equal-weight approximate posterior draws or explicit failure.

    ``deadline`` is an absolute time.perf_counter() deadline. Bounds: at most
    3840 mandatory proposals and exactly 4096 optional proposals per distinct
    nonempty channel history, unless the deadline aborts without a result.
    Empty histories use the continuous prior directly; source-count exclusions
    need no proposals. A mandatory second fixed batch is attempted only when
    the first lacks support. There are exactly count full-world draws and no
    clone/retry loop to inflate sampled diversity.
    Equal draw-weight ESS is reported separately from geometric pool ESS and
    realized active-position support, and is not an accuracy certificate.
    """
    if isinstance(count, bool) or not isinstance(count, int) or count < 1:
        raise BeliefSamplingError("count must be a positive integer")
    if isinstance(min_support, bool) or not isinstance(min_support, int) or not 1 <= min_support <= count:
        raise BeliefSamplingError("min_support must be an integer in 1..count")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise BeliefSamplingError("seed must be an integer")
    if deadline is not None:
        deadline = _number(deadline, "deadline")
    _check_deadline(deadline)
    histories, mandatory = _history_by_channel(history, deadline)
    cleared = {record["channel"] for record in history if record["result"] == "success"}
    rng, pools, cache = random.Random(seed), {}, {}
    for channel, events in histories.items():
        _check_deadline(deadline)
        if len(mandatory) == 16 and channel not in mandatory:
            pools[channel] = _LikelihoodPool((), (), -math.inf, dict(
                kind="source_count_excluded", log_evidence=None, zero_evidence=True))
            continue
        key = (events, channel in mandatory)
        if key not in cache:
            try:
                cache[key] = _conditional_pool(events, channel in mandatory, rng, min_support, deadline)
            except BeliefLowSupport as error:
                error.diagnostics["channel"] = channel
                raise
        pools[channel] = cache[key]
    optional = sorted(set(range(1, 21)) - mandatory)
    size, known = len(optional), len(mandatory)
    # Log elementary-symmetric sums preserve joint N/subset dependence and
    # avoid underflow when many channels have small existence evidence.
    suffix = [[-math.inf] * (size + 1) for _ in range(size + 1)]
    suffix[size][0] = 0.0
    for index in range(size - 1, -1, -1):
        suffix[index][0] = 0.0
        evidence = pools[optional[index]].log_evidence
        for needed in range(1, size - index + 1):
            suffix[index][needed] = _logadd(suffix[index + 1][needed],
                                            evidence + suffix[index + 1][needed - 1])
    totals = list(range(max(10, known), 17))
    total_logs = [suffix[0][total - known] - math.log(math.comb(20, total)) for total in totals]
    normalizer = _logsum(total_logs)
    if normalizer == -math.inf:
        raise BeliefSamplingError("No supported channel subset satisfies the public 10..16 source bound")
    total_weights = [math.exp(value - normalizer) for value in total_logs]
    worlds = []
    for index in range(count):
        _check_deadline(deadline)
        total = rng.choices(totals, weights=total_weights, k=1)[0]
        remaining, selected = total - known, set(mandatory)
        for offset, channel in enumerate(optional):
            if not remaining:
                break
            numerator = pools[channel].log_evidence + suffix[offset + 1][remaining - 1]
            probability = math.exp(min(0.0, numerator - suffix[offset][remaining]))
            if rng.random() < probability:
                selected.add(channel)
                remaining -= 1
        if remaining:
            raise BeliefSamplingError("Numerically degenerate joint channel-subset sample")
        sources = tuple(_source(channel, pools[channel], rng) for channel in sorted(selected))
        worlds.append(Scenario(
            f"q3-observation-belief-{seed}-{index:04d}", 3, rng.randrange(2**31), sources,
            "uniform", "Approximate finite-pool posterior of declared N/subset/disk/radius prior; "
            "integrated local quantizer likelihood; anchor historical fixed-key observations",
        ))
    active_signatures = [tuple((s.channel, s.x, s.y) for s in world.sources if s.channel not in cleared)
                         for world in worlds]
    positions_by_channel = {
        channel: len({(s.x, s.y) for world in worlds for s in world.sources if s.channel == channel})
        for channel in sorted(mandatory - cleared)
    }
    diagnostics = dict(
        model="declared_independent_fixed_key_uniform_error_local_Q",
        approximation="finite importance pools; optional existence evidence is bounded Monte Carlo",
        uniform_draw_weights=True, draw_weight_ess=float(count),
        distinct_active_position_worlds=len(set(active_signatures)),
        active_known_channel_draw_positions=positions_by_channel,
        per_channel={channel: pool.diagnostics for channel, pool in pools.items()},
        source_count_probabilities=dict(zip(totals, total_weights)),
        mandatory_channels=sorted(mandatory), cleared_channels=sorted(cleared),
        min_support=min_support,
    )
    _check_deadline(deadline)
    if diagnostics["distinct_active_position_worlds"] < min_support or any(
        distinct < min_support for distinct in positions_by_channel.values()
    ):
        raise BeliefLowSupport("Draws lack sufficient active-position support; fresh seeds/radii "
                               "and cleared sources do not count as additional support", diagnostics)
    return ConditionedWorlds(tuple(worlds), (1.0 / count,) * count, diagnostics)


__all__ = ["BeliefSamplingError", "BeliefSamplingTimeout", "BeliefLowSupport", "ConditionedWorlds",
           "quantized_bearing_likelihood", "history_log_likelihood", "sample_conditioned_worlds"]
