"""Public-observation snapshots and exact v1 macro continuations.

This module accepts no Scenario or engine. The caller supplies an ACTIVE
observation-only client already positioned at the snapshot (for example a
separate hypothetical client from make_q3_branch). Snapshots belong only at
macro boundaries, not inside a partly executed scan/resolve. A halted partial
macro may be captured for finalization, but can never be resumed as a macro.
"""

from copy import deepcopy
from dataclasses import asdict, dataclass
import math
import time

from simulator_client.errors import DeadlineExceeded, SimulatorError
from simulator_client.state import Position
from .relocating_state_search import RelocatingStateSearch
from .search import _StopSearch


# Explicitly exclude client, callbacks and additional research-planner state.
# Deep-copy these together to retain aliases between report logs and counters.
# A schema test covers every field initialized by frozen v1 at 8c624d0.
V1_FIELDS = (
    "state_config", "config", "problem", "variant", "max_actions",
    "max_active_probes", "active_policy", "points", "report", "regions",
    "first_bearings", "near_points", "observed_positions", "detected",
    "cleared", "actions", "blocked", "search_log", "total_expansions",
    "skipped_measurements", "discovery_stations", "remaining_covers",
    "coverage_replacements", "opportunistic_count", "probe_log", "refine_mode",
    "inferred_enabled", "inferred", "relocation_enabled", "relocation_log",
    "coverage_oracle",
)


def _task(task):
    if task is None:
        return None
    if not isinstance(task, (tuple, list)) or len(task) != 3:
        raise ValueError("task must be (source/cover, channel, Position)")
    kind, channel, point = task
    if kind not in ("source", "cover"):
        raise ValueError("unknown macro kind")
    if (kind == "source" and (type(channel) is not int or not 1 <= channel <= 20)
            or kind == "cover" and channel is not None):
        raise ValueError("invalid macro channel")
    return kind, channel, Position.coerce(point)


@dataclass(frozen=True)
class V1Snapshot:
    """Detached data; consumers must not mutate its nested state dictionaries."""
    public_state: object
    policy_state: dict
    remaining: tuple
    pending_task: tuple | None = None
    stop_reason: str | None = None
    plan_done: bool = False

    @property
    def history(self):
        """All real-to-this-branch observations, without an enter/exit record."""
        return deepcopy(self.policy_state["report"].action_history)


def capture_v1(parent, remaining, *, pending_task=None):
    """Capture before selection, or AFTER selection with pending_task supplied.

    Selection can move remaining covers and consume route budgets. Supplying
    the already selected task avoids doing that selection a second time.
    Only public client state is inspected; no client itself is copied.
    """
    if not isinstance(parent, RelocatingStateSearch) or parent.problem != 3:
        raise ValueError("snapshot requires the Q3 v1 strategy family")
    if parent.client.state.session != "active":
        raise ValueError("snapshot requires an active public session")
    if getattr(parent.client, "pending_request", None) is not None:
        raise ValueError("an uncertain physical action is not a macro boundary")
    if parent.actions != parent.client.state.accepted_actions:
        raise ValueError("strategy and public action counters disagree")
    remaining = [Position.coerce(p) for p in remaining]
    data = {name: getattr(parent, name) for name in V1_FIELDS}
    # The caller's live remaining list is authoritative. A boundary before the
    # first _next_task may still have the constructor's stale empty list here.
    data["remaining_covers"] = remaining
    copied = deepcopy(data)
    return V1Snapshot(deepcopy(parent.client.state), copied, tuple(remaining),
        _task(pending_task), getattr(parent, "_continuation_stop", None),
        getattr(parent, "_continuation_done", False))


@dataclass(frozen=True)
class MacroResult:
    snapshot: V1Snapshot
    task: tuple | None
    observations: tuple
    stop_reason: str | None
    terminal: bool
    virtual_cost_s: float
    generated_actions: int


class V1Continuation(RelocatingStateSearch):
    """Execute original v1 methods without reentering or replaying history.

    deadline is an absolute perf_counter deadline. action_limit bounds NEW
    measurement/clear calls in this continuation instance, excluding exit.
    The caller retains any global budget across separately constructed clones.
    step pauses with no exit; finish always uses the original run finalization.
    """

    def __init__(self, snapshot, client, *, deadline=None, action_limit=None):
        if not isinstance(snapshot, V1Snapshot):
            raise ValueError("expected V1Snapshot")
        if deadline is not None and (isinstance(deadline, bool)
                or not isinstance(deadline, (int, float)) or not math.isfinite(deadline)):
            raise ValueError("deadline must be a finite perf_counter time")
        if action_limit is not None and (type(action_limit) is not int or action_limit < 0):
            raise ValueError("action_limit must be a nonnegative integer")
        actual, expected = asdict(client.state), asdict(snapshot.public_state)
        # make_q3_branch intentionally owns a fresh local monotonic deadline.
        actual.pop("real_deadline")
        expected.pop("real_deadline")
        if actual != expected or actual["session"] != "active":
            raise ValueError("continuation client does not match public snapshot")
        if getattr(client, "pending_request", None) is not None:
            raise ValueError("continuation client has an uncertain action")
        self.__dict__.update(deepcopy(snapshot.policy_state))
        self.client = client
        self.remaining = list(snapshot.remaining)
        self.remaining_covers = self.remaining
        self._continuation_pending = snapshot.pending_task
        self._continuation_stop = snapshot.stop_reason
        self._continuation_done = snapshot.plan_done
        self._continuation_deadline = deadline
        self._continuation_action_limit = action_limit
        self._continuation_start_actions = self.actions
        self._continuation_finished = False

    def _planning_budget(self):
        if self._continuation_deadline is not None and time.perf_counter() >= self._continuation_deadline:
            raise _StopSearch("continuation_compute_budget")

    def _check_budget(self, action, position, channel):
        self._planning_budget()
        if (self._continuation_action_limit is not None
                and self.actions - self._continuation_start_actions >= self._continuation_action_limit):
            raise _StopSearch("continuation_action_limit")
        return super()._check_budget(action, position, channel)

    def snapshot(self):
        return capture_v1(self, self.remaining, pending_task=self._continuation_pending)

    def prepare_decision(self):
        """Select v1 once, preserving relocation and the pending macro.

        Calling twice before step is idempotent. Terminal states return None;
        finish remains responsible for closing the branch client.
        """
        if self._continuation_finished:
            raise ValueError("finished client cannot be snapshotted")
        if self._continuation_stop or self._continuation_done:
            return None, self.snapshot()
        try:
            self._planning_budget()
            if not self.remaining:
                self.report.coverage_complete = True
            if self._continuation_pending is None:
                self._continuation_pending = super()._next_task(self.remaining)
                if self._continuation_pending is None:
                    self._continuation_done = True
                self._planning_budget()
        except _StopSearch as error:
            self._continuation_stop = error.reason
        return (None if self._continuation_stop else self._continuation_pending), self.snapshot()

    def step(self, task=None):
        """Perform a supplied macro, the pending choice, or one original choice.

        A supplied task replaces only the pending task; it does not rerun
        selection or introduce a new cover. Clear points remain controlled by
        the original _resolve/_clear. Terminal results require finish for exit.
        """
        if self._continuation_finished or self._continuation_done or self._continuation_stop:
            raise ValueError("continuation is terminal; call finish instead")
        supplied = _task(task)
        before = len(self.report.action_history)
        start_time = self.client.state.virtual_time_s
        chosen = supplied or self._continuation_pending
        try:
            self._planning_budget()
            if not self.remaining:
                self.report.coverage_complete = True
            if chosen is None:
                chosen = super()._next_task(self.remaining)
                self._planning_budget()
            self._continuation_pending = None
            if chosen is None:
                self._continuation_done = True
            else:
                kind, channel, point = _task(chosen)
                if kind == "cover":
                    if point not in self.remaining:
                        raise ValueError("cover must be an existing unvisited station")
                    if self.state_config.stop_discovery_at_16 and len(self.detected | self.cleared) == 16:
                        raise ValueError("public source cap already stopped discovery")
                    self._scan(point)
                    self.remaining.remove(point)
                else:
                    if channel not in self.detected - self.cleared - self.blocked:
                        raise ValueError("source macro must be known, uncleared and unblocked")
                    if not self._resolve(channel):
                        self.blocked.add(channel)
                if not self.remaining:
                    self.report.coverage_complete = True
        except _StopSearch as error:
            self._continuation_stop = error.reason
        except DeadlineExceeded as error:
            self._continuation_stop = "real_deadline"
            self.report.error = str(error)
        except SimulatorError as error:
            self._continuation_stop = "protocol_error"
            self.report.error = f"{type(error).__name__}: {error}"
        observations = tuple(deepcopy(self.report.action_history[before:]))
        return MacroResult(self.snapshot(), chosen, observations, self._continuation_stop,
            bool(self._continuation_stop or self._continuation_done),
            self.client.state.virtual_time_s - start_time, len(observations))

    def _execute_plan(self):
        # The original run supplies completion classification and explicit exit.
        while not self._continuation_done:
            if self._continuation_stop:
                raise _StopSearch(self._continuation_stop)
            self.step()

    def finish(self):
        if self._continuation_finished:
            return self.report
        try:
            return super().run()
        finally:
            self._continuation_finished = True


__all__ = ["V1Snapshot", "MacroResult", "capture_v1", "V1Continuation"]
