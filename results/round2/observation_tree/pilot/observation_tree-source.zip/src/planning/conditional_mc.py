"""Finite nested conditional Monte Carlo; no state-dependent oracle actions.

An observation representative is drawn from the predictive distribution once.
Its conditional training worlds select one action, then fresh conditional
worlds evaluate that fixed action. Representatives are averaged, not reweighted
by the likelihood that already generated them. This is not full POMCPOW.
"""
from dataclasses import dataclass
import math
import statistics


@dataclass(frozen=True)
class ConditionalChoice:
    index: int
    training_costs: tuple[tuple[float, ...], ...]
    evaluation_costs: tuple[float, ...]

    @property
    def value(self):
        return statistics.fmean(self.evaluation_costs)


def finite_cost(value):
    if isinstance(value, bool) or not math.isfinite(value) or value < 0:
        raise ValueError("Only complete, finite, nonnegative continuation costs are comparable")
    return float(value)


def choose_then_evaluate(actions, training_worlds, evaluation_worlds, evaluate):
    """Choose once for the common observation, never separately per world."""
    if not actions or not training_worlds or not evaluation_worlds:
        raise ValueError("Nonempty actions and independent training/evaluation draws required")
    costs = tuple(tuple(finite_cost(evaluate(action, world)) for world in training_worlds)
                  for action in actions)
    selected = min(range(len(actions)), key=lambda i: (statistics.fmean(costs[i]), i))
    held_out = tuple(finite_cost(evaluate(actions[selected], world)) for world in evaluation_worlds)
    return ConditionalChoice(selected, costs, held_out)


def representative_average(first_costs, conditional_values):
    if not first_costs or len(first_costs) != len(conditional_values):
        raise ValueError("Each predictive representative needs its own conditional value")
    return statistics.fmean(finite_cost(c) + finite_cost(v)
                            for c, v in zip(first_costs, conditional_values))
