"""Nearest point in an intersection of equal-radius disks.

For a convex candidate source polygon, checking its vertices certifies every
point of the polygon: the distance to a fixed clear point is convex. In exact
arithmetic the finite candidates below contain the Euclidean projection onto
the disk intersection. Floating-point verification is deliberately separate
from that geometric completeness statement.
"""

from dataclasses import dataclass
import math

from simulator_client.state import Position


@dataclass(frozen=True)
class ClearLensResult:
    point: Position | None
    distance_m: float | None
    max_vertex_distance_m: float | None
    candidate_count: int
    feasible_count: int
    selected_kind: str


def nearest_clear_point(vertices, current, *, radius=19.9, incumbent=None,
                        feasibility_tolerance=1e-7):
    """Project ``current`` onto the intersection B(vertex, radius).

    The current point, single-circle radial projections and every pairwise
    circle intersection suffice. Repeated constraints are removed exactly;
    nearly repeated constraints remain in the final feasibility check. An
    optional feasible incumbent is retained on numerical ties, making the
    application robust without silently returning an infeasible candidate.

    If no candidate passes the numerical feasibility test, ``point`` is None.
    ``radius + feasibility_tolerance`` is the actual floating acceptance limit;
    callers requiring a strict physical threshold must check that separately.
    """
    if (isinstance(radius, bool) or not isinstance(radius, (int, float))
            or not math.isfinite(radius) or radius <= 0):
        raise ValueError("radius must be positive and finite")
    if (isinstance(feasibility_tolerance, bool)
            or not isinstance(feasibility_tolerance, (int, float))
            or not math.isfinite(feasibility_tolerance)
            or not 0 <= feasibility_tolerance <= 1e-5):
        raise ValueError("feasibility_tolerance must be in [0, 1e-5]")
    points = tuple(dict.fromkeys(Position.coerce(v) for v in vertices))
    if not points:
        raise ValueError("at least one constraint vertex is required")
    current = Position.coerce(current)
    candidates = []
    if incumbent is not None:
        candidates.append((Position.coerce(incumbent), "incumbent"))
    candidates.append((current, "current"))
    for center in points:
        distance = current.distance_to(center)
        if distance:
            scale = radius / distance
            candidates.append((Position(center.x + scale * (current.x-center.x),
                                        center.y + scale * (current.y-center.y)), "radial"))
    for i, a in enumerate(points):
        for b in points[i+1:]:
            dx, dy = b.x-a.x, b.y-a.y
            distance = math.hypot(dx, dy)
            # Coincident circles were removed. A tiny negative radicand near
            # tangency may be clamped, but never bypasses the all-vertex check.
            if distance > 2*radius + feasibility_tolerance:
                continue
            half = distance/2
            height = math.sqrt(max(0., (radius-half)*(radius+half)))
            mx, my = a.x+dx/2, a.y+dy/2
            ox, oy = -dy/distance*height, dx/distance*height
            candidates.append((Position(mx+ox, my+oy), "pair_intersection"))
            if height:
                candidates.append((Position(mx-ox, my-oy), "pair_intersection"))
    best = None
    feasible_count = 0
    for point, kind in candidates:
        maximum = max(point.distance_to(v) for v in points)
        if maximum > radius + feasibility_tolerance:
            continue
        feasible_count += 1
        distance = current.distance_to(point)
        # The incumbent appears first. Avoid changing a real observation site
        # for a sub-nanometre floating difference in this one-segment objective.
        if best is None or distance < best[0]-1e-9:
            best = (distance, point, maximum, kind)
    if best is None:
        return ClearLensResult(None, None, None, len(candidates), 0,
                               "infeasible_or_numerically_unresolved")
    return ClearLensResult(best[1], best[0], best[2], len(candidates),
                           feasible_count, best[3])
