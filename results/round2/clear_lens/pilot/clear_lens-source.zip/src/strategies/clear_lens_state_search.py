"""Q3 v1 scheduling with a larger certified clear set; no earlier clears."""

from dataclasses import asdict

from planning.clear_lens import nearest_clear_point
from simulator_client.state import Position
from .relocating_state_search import RelocatingStateSearch
from .search import _Search


class ClearLensStateSearch(RelocatingStateSearch):
    def __init__(self, client, max_actions, max_active_probes, config, enabled):
        super().__init__(client, max_actions, max_active_probes, config, True)
        self.clear_lens_enabled = enabled
        self.clear_lens_log = []
        self.report.strategy_parameters.update(
            clear_lens_enabled=enabled, clear_lens_log=self.clear_lens_log,
            clear_lens_scope="Incoming distance only; unchanged MEC trigger and near clear; no whole-episode dominance claim")

    def _clear(self, position, channel, phase):
        if not (self.clear_lens_enabled and phase == "certified_clear"
                and self.config.edge_clear):
            return super()._clear(position, channel, phase)
        region = self.regions[channel]
        disk = region.enclosing_disk()
        if not region.vertices or disk.radius > 19.9:
            return super()._clear(position, channel, phase)
        center = Position.coerce(disk.center)
        current = self.client.state.position
        distance = center.distance_to(current)
        safe_radius = max(0., 19.9-disk.radius)
        old = center
        if distance > 0:
            fraction = min(1., safe_radius/distance)
            old = Position(center.x+fraction*(current.x-center.x),
                           center.y+fraction*(current.y-center.y))
        result = nearest_clear_point(region.vertices, current, incumbent=old)
        selected = result.point
        valid = (selected is not None and result.max_vertex_distance_m < 20.
                 and result.distance_m <= current.distance_to(old)+1e-9)
        record = {"after_actual_action_count": len(self.report.action_history),
                  "channel": channel, "current": [current.x, current.y],
                  "vertices": [list(v) for v in region.vertices],
                  "mec_center": [center.x, center.y], "mec_radius_m": disk.radius,
                  "old_clear": [old.x, old.y], "accepted": valid,
                  **asdict(result)}
        if valid:
            record.update(selected_clear=[selected.x, selected.y],
                          incoming_saved_s=(current.distance_to(old)-result.distance_m)/5.,
                          physical_margin_m=20.-result.max_vertex_distance_m)
        self.clear_lens_log.append(record)
        if not valid:
            return super()._clear(position, channel, phase)
        # EfficientSearch._clear would replace this point by its MEC small
        # disk point again. Its only effect is that point replacement: calling
        # the base clear keeps the dynamic _perform chain, budgets and count
        # certificate, and the original phase unchanged.
        return _Search._clear(self, selected, channel, phase)


def run_clear_lens_state_search(client, *, problem=3, max_actions=10000,
                                max_active_probes=6, config=None, enabled=True):
    if problem != 3:
        raise ValueError("Clear lens state search is Q3 only")
    if type(enabled) is not bool:
        raise ValueError("enabled must be boolean")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("max_active_probes must be in [0,30]")
    return ClearLensStateSearch(client, max_actions, max_active_probes, config, enabled).run()
