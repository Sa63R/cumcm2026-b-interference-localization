"""Safe convex outer approximation after Q3 no-signal exclusion disks.

The hull of a convex polygon outside an open disk has extreme points only
at surviving polygon vertices and polygon-edge/circle intersections. Circular
arc interiors cannot be hull extremes: a short tangent segment through such
a point remains outside the disk. This module adds numerical slack and clips
the old outer polygon by an OUTWARD relaxation of that hull.
"""

from dataclasses import dataclass
import math

from geometry import HalfPlane, clip_polygon, convex_hull, distance, point
from .omni import OmniCandidateRegion


@dataclass(frozen=True)
class ExclusionHull:
    vertices: tuple
    status: str
    exclusion_radius_m: float
    outward_margin_m: float


def outside_disk_outer_hull(vertices, center, radius=1000.0):
    """Return an outer hull for P intersect {distance(center,x) >= radius}.

    Use an exclusion disk 0.1 mm smaller than the known radius, then expand
    computed hull half-planes outward by 1 micrometre. Numerically ambiguous
    tangent or excessively translated instances return the unchanged polygon.
    Empty results require every old vertex to lie strictly inside the smaller
    disk; convexity then certifies the entire old polygon was excluded.
    """
    vertices, center = tuple(point(p) for p in vertices), point(center)
    if (isinstance(radius, bool) or not isinstance(radius, (int, float))
            or not math.isfinite(radius) or radius <= 1e-4):
        raise ValueError("exclusion radius must be finite and greater than 1e-4")
    exclusion = radius - 1e-4
    scale = max([1.0, radius, abs(center[0]), abs(center[1])]
                + [abs(x) for p in vertices for x in p])
    slack = max(1e-6, 128 * math.ulp(scale))

    def result(value, status):
        return ExclusionHull(tuple(value), status, exclusion, slack)

    if not vertices:
        return result(vertices, "already_empty")
    if slack > 1e-5:
        return result(vertices, "numeric_scale_fallback")
    norms = [distance(p, center) for p in vertices]
    if min(norms) >= exclusion:
        # The disk may cut an interior hole, but the convex hull is unchanged.
        return result(vertices, "all_vertices_survive")
    if max(norms) < exclusion - slack:
        return result((), "polygon_inside_exclusion")
    retained = [p for p, norm in zip(vertices, norms) if norm >= exclusion - slack]
    for a, b in zip(vertices, vertices[1:] + vertices[:1]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        length = math.hypot(dx, dy)
        if length <= slack:
            # Degenerate edges need no new point. Their near-boundary vertices
            # are retained above, and the hull is expanded below.
            continue
        ux, uy = dx / length, dy / length
        rx, ry = a[0] - center[0], a[1] - center[1]
        perpendicular = abs(ux * ry - uy * rx)
        if perpendicular > exclusion + slack:
            continue
        if abs(perpendicular - exclusion) <= slack:
            return result(vertices, "tangent_numeric_fallback")
        foot = -(ux * rx + uy * ry)
        half_chord = math.sqrt((exclusion - perpendicular) * (exclusion + perpendicular))
        for along in (foot - half_chord, foot + half_chord):
            if -slack <= along <= length + slack:
                along = max(0.0, min(length, along))
                retained.append((a[0] + along * ux, a[1] + along * uy))
    hull = convex_hull(retained)
    if not hull:
        return result(vertices, "missing_intersection_fallback")
    constraints = []
    if len(hull) == 1:
        x, y = hull[0]
        constraints = [HalfPlane(1, 0, x + slack), HalfPlane(-1, 0, -x + slack),
                       HalfPlane(0, 1, y + slack), HalfPlane(0, -1, -y + slack)]
    elif len(hull) == 2:
        a, b = hull
        length = distance(a, b)
        ux, uy = (b[0] - a[0]) / length, (b[1] - a[1]) / length
        constraints = [HalfPlane(ux, uy, ux * b[0] + uy * b[1] + slack),
                       HalfPlane(-ux, -uy, -ux * a[0] - uy * a[1] + slack),
                       HalfPlane(-uy, ux, -uy * a[0] + ux * a[1] + slack),
                       HalfPlane(uy, -ux, uy * a[0] - ux * a[1] + slack)]
    else:
        for a, b in zip(hull, hull[1:] + hull[:1]):
            dx, dy = b[0] - a[0], b[1] - a[1]
            length = math.hypot(dx, dy)
            nx, ny = dy / length, -dx / length
            constraints.append(HalfPlane(nx, ny, nx * a[0] + ny * a[1] + slack))
    if any(hp.residual(p) > slack / 2 for hp in constraints for p in retained):
        return result(vertices, "hull_numeric_fallback")
    clipped = vertices
    for hp in constraints:
        clipped = clip_polygon(clipped, hp)
        if not clipped:
            # The all-inside case was handled explicitly. An unexpected empty
            # clipping outcome is a numerical failure, never an absence proof.
            return result(vertices, "empty_clip_fallback")
    return result(clipped, "outer_hull_clipped")


class NegativeHullRegion(OmniCandidateRegion):
    """Keep all original convex facts and replay all stored exclusion disks.

    Rebuild from the unexcluded base and lexicographically sorted negative
    coordinates. This avoids observation-arrival-dependent convexification,
    and restores old exclusions after a new bearing cuts through a filled hole.
    One pass is conservative; it is not the exact multi-disk feasible region.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._unexcluded_vertices = self.vertices
        self.hull_calls = 0
        self.hull_clips = 0
        self.hull_fallbacks = 0
        self.hull_empty = 0

    def _rebuild_exclusions(self):
        self._unexcluded_vertices = self.vertices
        for negative in sorted(self.no_signal_positions):
            if not self.vertices:
                break
            clipped = outside_disk_outer_hull(self.vertices, negative)
            self.hull_calls += 1
            self.hull_clips += clipped.status == "outer_hull_clipped"
            self.hull_fallbacks += clipped.status.endswith("fallback")
            self.hull_empty += clipped.status == "polygon_inside_exclusion"
            self.vertices = clipped.vertices
        self._circle = None

    def observe(self, position, bearing_deg):
        self.vertices = self._unexcluded_vertices
        self._circle = None
        super().observe(position, bearing_deg)
        self._rebuild_exclusions()
        return self

    def observe_no_signal(self, position):
        negative = point(position)
        if negative in self._no_signal_set:
            return self
        self.vertices = self._unexcluded_vertices
        self._circle = None
        super().observe_no_signal(negative)
        self._rebuild_exclusions()
        return self

