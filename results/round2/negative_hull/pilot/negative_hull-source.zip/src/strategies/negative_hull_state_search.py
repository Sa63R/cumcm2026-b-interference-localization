"""Q3 v1 strategy using stricter certified negative-observation geometry."""

from localization.negative_hull import NegativeHullRegion
from .relocating_state_search import RelocatingStateSearch


class NegativeHullStateSearch(RelocatingStateSearch):
    def __init__(self, client, max_actions, max_active_probes, config, enabled):
        super().__init__(client, max_actions, max_active_probes, config, True)
        self.negative_hull_enabled = enabled
        self.negative_hull_log = []
        self.report.strategy_parameters.update({
            "negative_exclusion_hull": enabled,
            "negative_hull_log": self.negative_hull_log,
            "negative_hull_scope": "Per-channel actual or certified-inferred Q3 no_signal excludes radius >=1000; conservative convex outer hull, canonical replay; no learned distribution or direction near-disk exclusion.",
            "negative_hull_numeric_slack": {"exclusion_shrink_m": 1e-4,
                                            "minimum_outward_margin_m": 1e-6},
        })

    def _perform(self, action, position, channel, phase):
        if self.negative_hull_enabled and action == "measure" and channel not in self.regions:
            self.regions[channel] = NegativeHullRegion()
        response = super()._perform(action, position, channel, phase)
        if self.negative_hull_enabled and action == "measure":
            region = self.regions[channel]
            self.negative_hull_log.append({
                "after_actual_action_count": len(self.report.action_history),
                "channel": channel, "result": response["measure_result"],
                "positive_observations": len(region.observations),
                "negative_positions": len(region.no_signal_positions),
                "base_vertices": len(region._unexcluded_vertices),
                "outer_vertices": len(region.vertices),
                "hull_calls": region.hull_calls, "hull_clips": region.hull_clips,
                "hull_fallbacks": region.hull_fallbacks, "hull_empty": region.hull_empty,
            })
        return response


def run_negative_hull_state_search(client, *, problem=3, max_actions=10000,
                                   max_active_probes=6, config=None, enabled=True):
    if problem != 3:
        raise ValueError("negative exclusion hull is Q3 only")
    if type(enabled) is not bool:
        raise ValueError("enabled must be boolean")
    if type(max_actions) is not int or max_actions < 2:
        raise ValueError("max_actions must be integer >=2")
    if type(max_active_probes) is not int or not 0 <= max_active_probes <= 30:
        raise ValueError("max_active_probes must be in [0,30]")
    return NegativeHullStateSearch(client, max_actions, max_active_probes, config, enabled).run()
